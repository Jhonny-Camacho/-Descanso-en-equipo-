# Etapa 2: cuentas y familias compartidas

Implementación sobre las mismas pantallas, estilos y reglas de la etapa 1. El espacio familiar usa un servidor y una base SQLite; no usa los datos de la demo ni simula identidades. No se ha contratado, conectado ni publicado ningún servicio externo.

## Elección del servicio

Autenticación: servicio propio de Node.js 24, correo y contraseña, derivación `scrypt` con sal individual, sesiones aleatorias de 256 bits (solo su hash se guarda en SQLite), cookie HttpOnly/SameSite=Strict, caducidad de siete días y cierre de sesión. HTTPS activa cookie Secure con prefijo `__Host-`. El servidor comprueba el origen exacto en todas las mutaciones y limita intentos de registro, acceso y creación de enlaces. No requiere cuenta de ChatGPT ni claves de un proveedor.

Base de datos: SQLite en disco, tablas de usuarios, sesiones, familias, miembros e invitaciones, claves foráneas, transacciones `BEGIN IMMEDIATE`, WAL y `synchronous=FULL`. Las consultas del plan incluyen la identidad de la sesión y la pertenencia familiar. La actualización exige además una revisión coincidente en SQL. Las invitaciones se consumen y añaden miembros dentro de una misma transacción.

Elegimos esta combinación porque permite implementar y verificar el recorrido real sin depender de credenciales externas ni activar una suscripción. Adecuada para esta entrega con un solo servidor. No es un despliegue público ni una arquitectura para múltiples servidores. SQLite no tiene políticas RLS ni usuarios por familia: la autorización se implementa en las consultas y transacciones del servicio, que es el único que abre el archivo. El navegador no tiene acceso SQL ni al archivo. No debe exponerse ese archivo en un alojamiento estático, carpeta pública o recurso compartido. No usar un disco efímero para familias reales.

## Primera ejecución, un paso cada vez

1. Comprueba que tienes **Node.js 24 o superior**: abre una terminal en la carpeta del proyecto y ejecuta `node --version`. Si falta, instala Node.js 24 LTS desde su sitio oficial antes de continuar.
2. Ejecuta `npm ci`. Instala las dependencias del proyecto, sin contratar servicios.
3. Ejecuta `npm run build`. Genera la demo independiente en `dist/` y la aplicación familiar en `dist-real/`.
4. Ejecuta `npm start` y deja esa terminal abierta. Crea automáticamente la base local `data/descanso.sqlite`.
5. En **ese mismo ordenador**, abre `http://localhost:3001/familia.html` en Chrome, en una pestaña normal. Esta dirección no es una URL pública y desde un teléfono apunta al propio teléfono. La demo sigue en `http://localhost:3001/` y en el HTML independiente.
6. Pulsa **Crear una cuenta**. Usa tu correo, un alias y una contraseña propia de al menos 12 caracteres. La contraseña se escribe únicamente en el formulario de la app, nunca en el chat. En esta versión todavía no se verifica el correo ni se recuperan contraseñas; para la prueba usa datos de prueba y una contraseña que no uses en otro servicio.
7. Crea la familia y elige una zona IANA, por ejemplo `America/La_Paz`. El plan comienza vacío. En **Mi equipo**, edita tu propia disponibilidad y si puedes cubrir relevos del bebé.
8. En **Invitaciones**, crea y copia el enlace privado. Solo quien creó la familia puede hacerlo o revocarlo. Caduca a las 48 horas y se consume al aceptarlo. El token solo aparece en el fragmento de la URL y se guarda como hash en el servidor. No lo publiques. Si recargas durante el registro, vuelve a abrir el enlace original para recuperar la invitación pendiente.
9. Para comprobarlo sin otro equipo, abre el enlace en una ventana de incógnito u otro perfil. Crea una segunda cuenta o entra con la del otro adulto y pulsa **Aceptar invitación privada**. Cada cuenta declara su propia disponibilidad. No copies las cookies de una cuenta a otra.
10. Desde **Plan semanal**, añade tareas con fecha, horario y responsable y reserva los descansos. El responsable entra con su cuenta y acepta. El otro navegador recoge cambios aproximadamente cada dos segundos; los formularios abiertos no se reemplazan. Para un turno nocturno, el fin debe indicar el día siguiente.
11. Recarga ambos navegadores. La cuenta y la familia seleccionada se conservan mediante sesión y URL; tareas, disponibilidad, estados y descansos proceden de SQLite. La demo local no se importa ni se modifica.

Si sale un conflicto, el cambio **no se sobrescribe**: se conserva el formulario y una copia del borrador en **Guardar copia / recuperar**. Copia los datos antes de pulsar **Cargar versión actual** y vuelve a aplicar el ajuste sobre esa versión. El borrador solo existe en esa pestaña; no se promete conservarlo al cerrar. Si se pierde la respuesta del servidor, puede haberse completado la escritura: carga la versión actual antes de repetirla. Los avisos de conexión hablan de guardado no confirmado, no de éxito.

## Para dos teléfonos de verdad

Hace falta un alojamiento con Node.js 24, **una sola instancia**, HTTPS y un volumen persistente. No se ha elegido ni contratado un proveedor. No necesitas crear una cuenta de Supabase/Firebase ni enviar claves. **El primer paso externo es comprobar si ya tienes un alojamiento que cumpla esas condiciones**, antes de elegir un proveedor o crear recursos.

Cuando exista ese alojamiento, configura estas variables en su panel privado (también disponibles como plantilla en `.env.example`):

- `APP_ORIGIN`: la dirección HTTPS exacta de la aplicación, sin barra final, por ejemplo `https://tu-dominio.example`. El navegador, los enlaces privados y las comprobaciones de origen deben usar esa misma dirección.
- `HOST=0.0.0.0`: permite que el proxy HTTPS del alojamiento alcance el proceso.
- `PORT`: el puerto interno que indique el alojamiento.
- `DB_PATH`: ruta absoluta del archivo SQLite **dentro del volumen persistente**, fuera de `dist/` y `dist-real/`. El proceso debe poder escribir también los archivos WAL/SHM junto a él.

Comando de instalación: `npm ci`. Compilación: `npm run build`. Inicio: `npm start`. El proxy debe servir la app desde ese mismo origen y dirigir también `/api/` al servidor; no añadir un origen diferente para la API. No habilitar acceso público directo al archivo SQLite. El proceso deniega el arranque externo con HTTP sin HTTPS en `APP_ORIGIN`.

La aplicación familiar se abre en una pestaña normal; las respuestas del servidor impiden incrustarla en sitios ajenos. Un contenedor de vista previa puede bloquear cookies o conexiones y no demuestra el funcionamiento público. La demo HTML sigue siendo local; no contiene el servidor y no permite colaboración desde `file:`.

Para copias operativas, detén el servidor antes de copiar el directorio de datos completo, guarda la copia en un lugar privado y prueba la restauración en otro directorio antes de sustituir el original. Borrar el volumen elimina cuentas y planes. No confundir el JSON del plan con una copia completa de usuarios, sesiones e invitaciones.

## Permisos y concurrencia

- Sin sesión no hay acceso a planes ni invitaciones. El servidor obtiene el usuario de la cookie, nunca de `actor`, parámetros de usuario o botones visibles.
- Leer y escribir el plan exige una fila en `members` para la sesión actual y la familia solicitada. Una familia ajena obtiene 404. Los listados solo devuelven familias propias.
- Solo el creador crea, lista o revoca invitaciones. Cada enlace admite una incorporación. No se pueden fabricar miembros enviando un plan modificado.
- Cada adulto edita únicamente su alias y disponibilidad, y acepta o completa únicamente sus propias tareas. Los miembros colaboran en las propuestas, cancelaciones, descansos, nombre familiar y revisión. El creador no puede aceptar por otro adulto.
- El servidor vuelve a comprobar intervalos, referencias, estados, disponibilidad y cruces. Una edición de horario, tipo, nota o responsable exige volver a propuesta. Un cambio de disponibilidad puede señalar compromisos ya aceptados sin reasignarlos, igual que en la demo.
- Las revisiones son de todo el plan: incluso cambios en campos diferentes pueden producir un conflicto. No existe fusión automática. La comprobación y escritura se realizan en la misma transacción. Un rechazo deja la base anterior intacta.

## Qué queda pendiente

Despliegue HTTPS, volumen real y política de copias del alojamiento; prueba desde dos teléfonos/redes físicos; verificación de correo y recuperación de contraseña antes de abrir el registro al público; revisión de seguridad independiente y operación de un servicio público. No hay envío de correo configurado, pagos, integración automática con WhatsApp ni servicios externos activos. Los PDF siguen siendo impresión del navegador y los enlaces WhatsApp solo preparan texto.

Las cuentas de prueba automatizadas y sus bases temporales se crean localmente para las pruebas; no representan familias de usuarios ni un servicio público disponible. No introducir datos familiares reales en una instalación pública sin completar los pendientes.

## Corrección de apertura en Windows

El paquete inicial rechazaba las páginas en Windows porque comprobaba las rutas con un separador `/` fijo. La versión corregida usa las reglas de rutas del sistema y conserva el bloqueo de archivos fuera de las carpetas compiladas. El error «Página no encontrada. Ejecuta npm run build» también podía aparecer por ese rechazo aunque la compilación estuviera incluida.

Se reproduce el fallo original con `node:path.win32` y se comprueban rutas de unidades, carpetas con espacios, recursos, rutas UNC y rechazos fuera de la raíz. La prueba HTTP comprueba la página y los recursos. Esto no equivale a ejecutar el servidor en Windows: la confirmación final en un equipo Windows sigue siendo necesaria.

Para actualizar una carpeta existente, detén primero el servidor y sustituye los archivos de programa con el ZIP corregido. Conserva `data/`, `.env` y tus copias privadas; no están incluidos en la distribución y no deben borrarse. Después vuelve a iniciar el servidor con `INICIAR-WINDOWS.cmd`.
