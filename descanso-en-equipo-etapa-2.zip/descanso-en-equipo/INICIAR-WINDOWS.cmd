@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto falta_node
node -e "if(Number(process.versions.node.split('.')[0])<24)process.exit(1)"
if errorlevel 1 goto falta_node
if exist "node_modules\@js-temporal\polyfill\package.json" goto iniciar
echo Instalando las dependencias desde package-lock.json...
call npm.cmd ci --omit=dev --no-audit --no-fund
if errorlevel 1 goto error
:iniciar
echo Mantenga abierta esta ventana mientras use la aplicacion.
echo Cuando aparezca el mensaje de arranque, abra Chrome en este ordenador.
echo Direccion local, disponible solo mientras el servidor este iniciado:
echo http://localhost:3001/familia.html
call npm.cmd start
if errorlevel 1 goto error
goto fin
:falta_node
echo Primero instale Node.js 24 LTS o superior desde https://nodejs.org/
echo Cierre esta ventana y vuelva a abrir el iniciador despues de instalarlo.
goto fin
:error
echo No se ha podido iniciar. Conserve el mensaje de error que aparece arriba.
:fin
pause
