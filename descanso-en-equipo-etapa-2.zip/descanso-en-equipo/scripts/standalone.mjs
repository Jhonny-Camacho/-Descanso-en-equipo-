// Package the same verified Vite build into a downloadable, offline demo.
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const root = resolve('dist');
let html = await readFile(resolve(root, 'index.html'), 'utf8');
const script = html.match(/<script\b[^>]*\bsrc="([^"]+)"[^>]*><\/script>/);
const style = html.match(/<link\b[^>]*\bhref="([^"]+\.css)"[^>]*>/);
if (!script || !style) throw new Error('No se encontraron los recursos compilados de la demo.');
const js = await readFile(resolve(root, '.' + script[1]), 'utf8');
const css = await readFile(resolve(root, '.' + style[1]), 'utf8');
html = html.replace(script[0], () => `<script type="module">${js.replace(/<\/script/gi, '<\\/script')}</script>`);
html = html.replace(style[0], () => `<style>${css}</style>`);
await writeFile(resolve(root, 'descanso-demo.html'), html);
console.log('Demo descargable generada: dist/descanso-demo.html');
