import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../server/server.js';
const directory=mkdtempSync(join(tmpdir(),'descanso-browser-'));
const app=createApp({dbPath:join(directory,'test.sqlite'),origin:'http://127.0.0.1:3004'});
app.server.listen(3004,'127.0.0.1');
async function shutdown(){await app.close();rmSync(directory,{recursive:true,force:true});process.exit(0);}
process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
