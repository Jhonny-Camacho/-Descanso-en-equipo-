# Progreso · Descanso en equipo

## Alcance y decisiones

La solicitud del archivo «Texto pegado.txt» autoriza construir únicamente la etapa 1. El repositorio estaba vacío, sin commits, dependencias ni instrucciones AGENTS.md. Se mantiene el checkout existente, sin worktrees. No se han contratado servicios ni publicado producción.

Arquitectura elegida: Vite + JavaScript modular + CSS; `@js-temporal/polyfill` para fechas completas y zonas IANA. Datos de demostración en una única clave local; escape de texto al renderizar contenido editable. Pruebas con Node, Playwright, Chromium del sistema y axe.

## Implementado

- [x] Presentación con propuesta de valor, ejemplo de plan, tres pasos y FAQ.
- [x] Familia ficticia de tres adultos y persona simulada claramente identificada.
- [x] Configurador de cuatro pasos, guardado parcial y confirmación de reemplazo.
- [x] Disponibilidades distintas, varias franjas por adulto y turnos nocturnos.
- [x] Catálogo editable mediante formularios y tareas personalizadas.
- [x] Propuestas deterministas dentro de disponibilidad y tareas sin cobertura.
- [x] Aceptar, rechazar (cancelar), realizar, editar y reasignar.
- [x] Bloqueo de solapamientos aceptados; límites consecutivos permitidos.
- [x] Nueva confirmación tras cambiar horario, responsable o contenido.
- [x] Aviso por cambios de disponibilidad sin reasignaciones silenciosas.
- [x] Hoy, semana, equipo y revisión opcional.
- [x] Descansos previstos diferenciados de cobertura aceptada por otro adulto.
- [x] Copiar semana anterior sin estados de aceptación/cumplimiento; confirmación previa al reemplazo.
- [x] Preparación de WhatsApp y copia, sin envío automático ni enlaces de sincronización.
- [x] Impresión/PDF A4.
- [x] Reinicio confirmado limitado a la clave de esta demo.
- [x] Diseño móvil, teclado, etiquetas y foco visible.

## Verificaciones

- `npm test`: 24 pruebas de reglas y almacenamiento, aprobadas.
- `npm ci --cache /workspace/.npm-cache --no-audit --no-fund`: reinstalación con lockfile aprobada.
- `npm run build`: compilación final aprobada; genera el build y `dist/descanso-demo.html`.
- `npm run test:e2e`: 26 pruebas de navegador aprobadas; 0 fallidas y 0 omitidas. Incluyen recorrido con tres adultos, aceptación/rechazo, persistencia, turnos nocturnos, solapamiento real desde la interfaz, tareas consecutivas, cambio de disponibilidad, copia, portapapeles, PDF, reinicio y móvil/teclado.
- Accesibilidad axe WCAG A/AA: sin infracciones detectadas en las seis pantallas y el diálogo de tarea. Se corrigieron los contrastes detectados. No equivale a una auditoría humana completa.
- HTML empaquetado comprobado bajo HTTP: navegación, persistencia y cero recursos externos. La apertura directa mediante `file:` fue bloqueada por la política de Chromium del entorno y no se afirma como verificada.
- PDF real generado y leído: dos páginas A4, 21 tareas, horario, responsable y estado.
- Servidor de desarrollo: HTTP 200, título esperado y módulo de aplicación servido en el puerto 5173.
- Inspección visual de capturas de escritorio y móvil realizada.

Problemas encontrados y corregidos durante el trabajo: una asignación ficticia del domingo fuera de disponibilidad; cierre de diálogo que podía afectar al siguiente; variable faltante al generar un plan. Las pruebas de recorrido detectaron también selectores ambiguos de pruebas, corregidos. npm usa caché escribible en `/workspace/.npm-cache`. La descarga opcional de Playwright fue bloqueada por la red; se utiliza Chromium ya instalado, sin modificar TLS ni verificación.

## Estado para retomar

Etapa 1 implementada y verificada. Servidor de desarrollo activo en 0.0.0.0:5173 para revisión. También está disponible `dist/descanso-demo.html`, un único HTML navegable. Instrucciones y límites en README.md. Campos `install_script` y `start_skill` guardados en el borrador de configuración del entorno; guardarlos no ejecuta comandos ni publica. La reutilización del entorno requiere revisar/guardar y publicar la configuración desde sus ajustes; esa publicación del entorno no es un despliegue de producción de la aplicación. No se ha comprobado restauración en una tarea nueva. Los procesos no se conservan: usar las instrucciones de arranque. No hay pasos de desarrollo de la etapa 1 pendientes; las verificaciones externas siguientes permanecen explícitas.

## Límites reales y pendientes

- Solo almacenamiento en este navegador/dispositivo; no cuentas, sincronización, invitaciones ni roles reales.
- Las acciones de confirmación prueban una persona simulada, sin autenticarla.
- Apertura directa del HTML descargado pendiente de verificar en un navegador personal; comprobado el mismo archivo bajo HTTP.
- No hay pruebas con WhatsApp real ni mensajes enviados; solo preparación de URL y portapapeles comprobado.
- PDF generado automáticamente; falta comprobar impresora física y otros navegadores.
- Pruebas en Chromium y móvil emulado; faltan iOS/Safari, Android físico y lector de pantalla humano.
- La cobertura requiere un único relevo aceptado que abarque el bloque completo. No suma relevos parciales; ajustar el bloque o proponer un relevo completo.
- Horas ambiguas/inexistentes de cambio horario se rechazan; no se escoge silenciosamente una de las dos.
- Una sola pestaña recomendada: no hay resolución de ediciones simultáneas locales.
- Etapa 2: cuentas por correo, base de datos, colaboración protegida, permisos, aislamiento de familias, invitaciones y revocación, concurrencia, exportación y borrado. Requiere elegir proveedor y configurar credenciales de forma segura.
- Etapa 3: pruebas con dos cuentas/dos familias, revisión de seguridad/privacidad, dispositivos y accesibilidad humanos, piloto comercial manual. Precio y acceso comercial todavía no se muestran como oferta ni se cobran.

## Corrección del guardado de «Editar tarea» · 24/10/2026

Caso solicitado: aceptar el relevo de Leo del martes 20/10/2026, 19:00–20:00 (America/La_Paz), cambiarlo a 19:30–20:30 y guardar.

**Reproducción y causa:** en una ventana normal el caso guardaba; en una vista incrustada con scripts y almacenamiento permitidos, pero sin envíos nativos de formularios, el botón dejaba el diálogo abierto sin error. La prueba de regresión falló antes del cambio. El único manejador estaba en el evento `submit`, que ese contenedor bloqueaba antes de invocarlo. Leo tiene disponibilidad de lunes a viernes entre las 18:00 y las 23:00, por lo que el intervalo solicitado es válido y no debe rechazarse por disponibilidad.

**Cambios:** el diálogo intercepta la activación del botón de envío antes del envío nativo y ejecuta la misma acción local, conservando `reportValidity()`, campos requeridos, restricciones del navegador y validaciones de fechas, disponibilidad y tipo de cuidado. El envío por teclado mantiene la misma ruta. Los errores aparecen dentro del diálogo, reciben foco y se desplazan a la zona visible; no se reconstruye el formulario ni se pierden los valores. Al guardar una tarea también se comprueban cruces con otros compromisos aceptados de la misma persona, excluyendo la propia tarea. Siguen permitiéndose límites consecutivos. Un cambio válido cierra el diálogo y vuelve a propuesta; no se han reiniciado datos ni cambiado la disponibilidad de Leo.

**Verificación:** 17 pruebas de reglas aprobadas. Las regresiones específicas de navegador comprueban el caso exacto, ventana normal, vista incrustada, persistencia tras recargar, error visible en móvil por fuera de disponibilidad, conservación de fechas y nota, reintento válido, cruce con otro compromiso, límite consecutivo, campos vacíos, fin anterior al inicio y guardado con Enter. Compilación aprobada y HTML descargable regenerado. Suite completa de navegador: 22 aprobadas, 0 fallidas y 0 omitidas, incluido el caso exacto en el HTML empaquetado incrustado. Total: 39 pruebas aprobadas. Los controles anteriores de accesibilidad, móvil, impresión y resto del recorrido también siguen pasando.

## Corrección de persistencia · 24/10/2026

**Acceso y reproducción:** no hay herramienta que permita inspeccionar la vista real ni el almacenamiento del navegador del usuario. Se reprodujo el recorrido completo en Chromium con el HTML compilado incrustado: aceptar el relevo del martes 20/10, editar a 19:30–20:30, volver a aceptar, quitar el descanso de Ana de 19:00–20:00 y crear uno de 19:30–20:30.

Con almacenamiento permitido, horario, aceptación y descanso con cobertura de Leo permanecen tras recargar. El contenido bruto bajo la misma clave es idéntico antes y después: no hay sustitución por la familia de ejemplo ni cambio de clave. En un iframe con scripts permitidos pero origen opaco, `localStorage` lanza realmente `SecurityError` y la versión anterior pierde los cambios al recargar, reproduciendo exactamente los valores iniciales comunicados. Esto prueba una condición reproducible, no confirma la política exacta del contenedor del usuario. También se simuló un fallo de escritura `QuotaExceededError` en una vista de origen estable.

**Defecto confirmado y cambios:** la versión anterior atrapaba el error de escritura, pero seguía emitiendo mensajes de éxito y mostraba un banner que prometía guardado local. Ahora el acceso se comprueba al inicio y cada escritura se lee de nuevo para verificarla. Los fallos se muestran como «Solo en esta pestaña · no se conservará al recargar», sin mensajes de guardado exitoso. Los datos ilegibles anteriores no se sobrescriben por semillas al interactuar con la demo; se ofrece su texto sin modificar para preservarlos. La clave `descanso-en-equipo.demo.v1` se mantiene.

**Alternativa probada:** «Guardar copia / recuperar» exporta texto JSON validado con tareas, aceptación, descansos y configuración. Se puede conservar manualmente en un archivo o nota privada. Si el portapapeles automático está bloqueado, se selecciona el texto y se indica cómo copiarlo manualmente, sin fingir que se ha copiado o descargado. Tras una recarga de la vista bloqueada, pegar la copia, revisarla y confirmar restaura horario, aceptación y descanso con cobertura. La misma copia recuperada en una vista distinta con almacenamiento permitido también permanece al recargar. La importación valida estructura, referencias, fechas y cruces aceptados; requiere confirmación y no altera datos ante copias inválidas.

**Verificado:** 24 pruebas unitarias aprobadas y 26 de navegador aprobadas, con las cuatro nuevas comprobaciones de persistencia completa, bloqueo real, fallo de escritura y datos corruptos. Sin fallos ni omisiones en la suite. Se conservan las validaciones de horarios, disponibilidad, confirmación y cruces, las pruebas de teclado, impresión y accesibilidad existentes. Compilación y demo HTML regeneradas.

**Límites:** la app no puede forzar almacenamiento persistente en un origen bloqueado, impedir que un contenedor cambie de origen/partición ni recuperar cambios ya perdidos sin una copia. No se verificó la sesión real del usuario ni apertura directa por `file:`. La prueba de recuperación en entorno bloqueado verificó el texto exportado, su selección cuando el portapapeles estaba denegado y el pegado/importación de esos mismos datos; no se afirmó descarga automática ni envío a ningún servicio.

## Etapa 2: servidor y familias con cuentas

Se conserva el proyecto y su diseño. Servicio propio con Node.js 24 y SQLite; sin proveedor externo conectado, sin pagos ni despliegue público. `familia.html` es la entrada familiar y `/` conserva la demo local. Compilaciones separadas en `dist-real` y `dist`; los datos de ejemplo no se importan en el servidor.

Implementado: registro con correo y contraseña derivada por scrypt, sesiones HttpOnly con caducidad, cierre de sesión, creación de familia vacía, disponibilidad individual, invitaciones privadas de un solo uso válidas 48 horas, revocación por el creador, incorporación mediante otra cuenta, plan compartido consultado cada 2 segundos, aceptación/completado solo por el responsable. Reutiliza tareas, edición y reconfirmación, cobertura de descansos, revisión semanal, PDF y texto WhatsApp. Las mutaciones se confirman después de la escritura de SQLite; no se sustituye por localStorage si falla el servidor.

Autorización: la sesión determina la identidad, el actor enviado se descarta; consultas SQL con membresía; actualización condicionada por membresía y revisión en transacción; validaciones del plan y de transiciones también en servidor. No hay acceso SQL desde el navegador ni RLS nativo en SQLite. El servicio es el único que abre el archivo. Concurrencia: 409 ante revisión antigua, conservación de campos y copia del borrador, carga explícita de versión actual; sin fusión ni reintento que sobrescriba cambios.

Verificación automatizada: 37 pruebas Node (24 existentes y 13 de API/SQLite), 26 de la demo y 3 recorridos de navegador con cuentas independientes, servidor HTTP y SQLite reales. El recorrido usa Ana y Leo, invitación y registro, disponibilidad propia, tarea del 20/10/2026, aceptación, edición a 19:30–20:30, nueva aceptación, descanso con cobertura, recarga de ambas sesiones, revisión, WhatsApp y PDF. Pruebas adicionales intentan leer/escribir otra familia, falsificar actor/membresía, aceptar tareas ajenas, saltar disponibilidad/cruces, usar enlaces caducados/revocados/reutilizados, escribir simultáneamente y perder la conexión. Una respuesta de lectura atrasada tampoco puede revertir una revisión posterior confirmada. Otra prueba cierra y vuelve a abrir el servidor para comprobar cuenta, sesión y familia en disco. No se enviaron correos ni mensajes WhatsApp. PDF generado por Chromium.

Durante las pruebas se corrigió la apertura de una invitación mediante cambio de fragmento desde una pestaña ya abierta. Las pruebas esperan los datos actualizados antes de la siguiente escritura; si escriben antes, el servidor rechaza la versión antigua, como corresponde. Los formularios conservan los datos ante ese rechazo.

Pendientes: alojamiento HTTPS con volumen persistente y una instancia; dos dispositivos físicos/redes reales; verificación de correo y recuperación de contraseña; revisión independiente antes de registro público. No se ha demostrado funcionamiento dentro de la vista incrustada del usuario ni fuera del entorno local. Instrucciones de principiantes y configuración en `ETAPA-2.md` y `.env.example`. No se solicitaron contraseñas ni claves en el chat.

## Corrección de servidor estático en Windows

El usuario inició correctamente Node.js 24.12.0 y el servidor en Windows, pero `/familia.html` respondió con 404. Se identificó el defecto: `file.startsWith(base + '/')` nunca coincidía con las rutas de Windows que contienen `\\`. La nueva comprobación usa `path.relative`, el separador nativo y `path.isAbsolute`; bloquea la raíz, rutas padre, unidades diferentes y prefijos de carpetas adyacentes.

Se añadieron pruebas con las reglas win32 (incluidos espacios y UNC), posix y HTTP para HTML/recursos, sin relajar el aislamiento. No se ejecutó Windows en el entorno cloud. Se prepara el ZIP corregido para actualizar los archivos de programa sin incluir ni borrar bases de datos de usuarios.
