# Descanso en equipo

El proyecto incluye ahora dos espacios separados:

- **Familias con cuentas**: `/familia.html`, servicio Node.js 24 y SQLite en disco. Registro, sesiones, invitaciones privadas, permisos, guardado compartido y control de conflictos. Instrucciones de principiantes, configuración y límites en [ETAPA-2.md](ETAPA-2.md).
- **Demo local**: `/` y `dist/descanso-demo.html`, con datos ficticios y almacenamiento del navegador. Las instrucciones siguientes describen este modo; sus ejemplos no se importan en familias con cuentas.

Para probar el servicio familiar desde este ordenador: `npm ci`, `npm run build`, `npm start`; después abre `http://localhost:3001/familia.html` en una pestaña normal. No es una URL pública. No hay servicios externos ni pagos activados. Para dos teléfonos hace falta alojar el servidor con HTTPS y volumen persistente, aún pendiente.

Verificación: `npm test` (reglas, almacenamiento y API), `npm run test:e2e` (demo) y `npm run test:real` (dos cuentas en navegadores independientes contra el servidor real y SQLite). Compila primero. Los datos de las pruebas son temporales; no se mezclan con `data/descanso.sqlite`.

## Demostración local de la etapa 1

Demostración funcional de la **etapa 1**. Ayuda a proponer, repartir y confirmar responsabilidades familiares. No promete horas de sueño ni ofrece recomendaciones clínicas.

## Abrir la aplicación

**Sin instalar herramientas:** abre `dist/descanso-demo.html` en tu navegador. Es una copia navegable de la misma aplicación, empaquetada en un solo archivo y sin conexiones externas. Conservar ese archivo en la misma ubicación ayuda a reutilizar su almacenamiento, pero no garantiza persistencia; guarda también una copia del plan; el acceso a datos bajo `file:` puede variar según el navegador. El HTML empaquetado se verificó en Chromium servido por HTTP, sin cargar recursos externos. La apertura directa de archivos está bloqueada por la política del navegador de este entorno, así que esa modalidad queda pendiente de verificar en un navegador personal.

**Para desarrollar o usar el servidor:**

Desde la carpeta del proyecto, con Node.js 24 o superior (verificado con Node 24):

```sh
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
npm run dev -- --port 5173 --strictPort
```

El servidor muestra la dirección para abrirla en el navegador. En el entorno cloud escucha en el puerto **5173**, en todas las interfaces. No se ha desplegado una versión pública. Si la herramienta de trabajo permite abrir puertos, usa el 5173. Sin acceso a puertos, descarga el proyecto y ejecuta los mismos comandos en tu ordenador (puedes omitir la opción `--cache` allí).

1. Pulsa **Probar demostración** para explorar la familia ficticia de Ana, Leo y Elena.
2. Cambia **Simulando a** para aceptar o rechazar propuestas de cada persona. Esto no es autenticación.
3. **Crear mi plan** abre cuatro pasos. Puedes guardar y volver después; el último paso pide confirmar el reemplazo de los datos locales.
4. En **Plan semanal**, añade o edita tareas. Para un turno nocturno, indica la fecha del día siguiente como fin.
5. **Necesito un relevo** prepara texto para WhatsApp o para copiar. Tú decides si lo envías.
6. **Imprimir / PDF** abre el diálogo del navegador; selecciona Guardar como PDF.
7. **Guardar copia / recuperar**, en el aviso superior o en el pie de página, muestra un texto con el plan completo. Cópialo y pégalo en un archivo o nota privada antes de recargar si aparece el aviso de falta de almacenamiento. Para recuperarlo, pega el texto en ese mismo diálogo, pulsa **Revisar recuperación** y confirma. Si copiar automáticamente está bloqueado, el texto queda seleccionado para usar Copiar o Ctrl/Cmd+C. No se afirma que un archivo esté guardado automáticamente.
8. **Reiniciar demo**, en el pie de página, pide confirmación y solo restablece los datos de esta aplicación.

## Qué contiene

- Presentación, preguntas frecuentes y vista ilustrativa de un plan.
- Configurador local: alias familiar, zona horaria IANA, adultos, disponibilidad, tareas y descanso previsto.
- Hoy, plan semanal, equipo y revisión semanal con respuesta opcional.
- Tareas con fechas completas, responsable y estados propuesta/aceptada/realizada/cancelada. Rechazar cancela la propuesta; editarla permite volver a proponerla.
- Reparto determinista con disponibilidad semanal, franjas que cruzan medianoche, equilibrio por número de tareas propuestas y detección de solapamientos. No pretende medir la carga real o la dificultad de cada tarea.
- Solo el responsable simulado acepta; las ediciones vuelven a propuesta. Se bloquea aceptar compromisos solapados y se permiten consecutivos.
- Aviso antes de guardar disponibilidad que afecte compromisos; no se reasignan tareas aceptadas.
- Ayuda doméstica diferenciada de la capacidad de cubrir relevos del bebé.
- Descanso previsto y cobertura aceptada diferenciados. El bloque solo aparece cubierto cuando un relevo aceptado de otro adulto abarca todo el intervalo.
- Copia de tareas de la semana anterior sin estados de cumplimiento. Confirmación antes de sustituir tareas existentes. Los bloques de descanso permanecen y hay que revisar su cobertura.
- Mensaje con fechas, intervalo y zona horaria. Sin envío automático ni enlaces de supuesta sincronización.
- Resumen de impresión A4, diseño móvil, etiquetas, teclado, foco visible y diálogos nativos.

## Datos y privacidad

La clave del plan sigue siendo `descanso-en-equipo.demo.v1` en `localStorage` del navegador; no se cambia con esta actualización. Se comprueba el acceso al inicio y se verifica por lectura cada escritura. Un plan válido se carga sin sustituirlo por ejemplos. Un registro ilegible se conserva y no se sobrescribe automáticamente. Una prueba temporal de disponibilidad usa una clave propia `.probe`, que se elimina enseguida. No hay servidores de datos, cuentas, analítica, pagos, invitaciones ni sincronización. Usa alias y datos ficticios, especialmente en dispositivos compartidos. No incluyas información clínica en las notas. Borrar los datos del navegador elimina el plan; reiniciar la demo pide confirmación. El texto que decidas enviar por WhatsApp se rige también por ese servicio.

Las horas se interpretan en la zona horaria de la familia, no en la del equipo que abre la página. Temporal rechaza las horas inexistentes o ambiguas durante cambios de horario de verano, para evitar elegir un horario silenciosamente. En esos casos hay que ajustar la hora. Una franja con fin igual al inicio representa 24 horas y termina al día siguiente.

Algunas vistas incrustadas bloquean `localStorage` (por ejemplo, una vista con origen opaco), cambian su espacio de almacenamiento al abrir otra vista o eliminan los datos al cerrarla. La app no controla esas políticas. Si el acceso o la escritura fallan, muestra **Solo en esta pestaña · no se conservará al recargar** y sustituye los mensajes de guardado por avisos de cambios solo en memoria. El botón **Guardar copia / recuperar** permite conservar y restaurar manualmente tareas, estados de aceptación, descansos y configuración sin depender del almacenamiento de la vista. La copia se valida y se pide confirmación antes de reemplazar el plan.

Una escritura y lectura correctas no demuestran que el contenedor conservará su almacenamiento entre sesiones, vistas, archivos o dispositivos. Usa copias del plan. No existe control de concurrencia entre pestañas ni respaldo automático fuera del dispositivo; para la demo conviene usar una sola pestaña. No introducir datos familiares reales antes de implementar la etapa 2.

## Estructura y verificación

JavaScript modular y CSS, sin framework ni servicios externos. Vite sirve y compila la aplicación; Temporal maneja fechas y zonas horarias.

- `src/planner.js`: reglas comprobables de planificación, cobertura y fechas.
- `src/app.js`: pantallas, formularios, avisos de persistencia, copia/recuperación y acciones.
- `src/storage.js`: acceso verificado al almacenamiento, protección de datos ilegibles y validación de copias.
- `src/style.css`: diseño adaptable e impresión.
- `tests/planner.test.js` y `tests/storage.test.js`: reglas y persistencia con el ejecutor de Node.
- `tests/browser/persistence.spec.js`: recorrido completo con horario, aceptación y descanso; almacenamiento permitido, bloqueado, escritura fallida y recuperación.
- `tests/browser/app.spec.js`: recorrido real de navegador y accesibilidad con Playwright y axe.
- `PROGRESO.md`: estado, resultados y trabajo siguiente.

```sh
npm test
npm run build
npm run test:e2e
```

`npm run build` también genera `dist/descanso-demo.html`. Haz esa compilación antes de ejecutar la suite del navegador, que comprueba además el HTML empaquetado bajo HTTP sin recursos externos.

Las pruebas de navegador usan Chromium del sistema (`/usr/bin/chromium`). Si está en otra ubicación, define `CHROMIUM_PATH` con la ruta del ejecutable. No se necesita descargar otro navegador en este entorno. Playwright arranca su servidor de pruebas automáticamente o reutiliza el servidor del puerto 5173 fuera de CI. Los resultados y el PDF generado están en `test-results/` (no se incluyen en Git).

## Estado de la etapa 2

La implementación del servidor está documentada en [ETAPA-2.md](ETAPA-2.md). Las cuentas y las familias usan ese servicio; la demo descrita arriba conserva sus límites locales. Quedan pendientes alojamiento HTTPS con disco persistente, prueba con dos teléfonos físicos, verificación de correo, recuperación de contraseña y revisión de seguridad para registro público. No hay un servicio público desplegado.

La etapa 3 incluye revisión humana con familias piloto, accesibilidad con tecnología de asistencia y dispositivos reales, seguridad y privacidad, y preparación comercial. No hay ofertas, cobros ni producción activados.
