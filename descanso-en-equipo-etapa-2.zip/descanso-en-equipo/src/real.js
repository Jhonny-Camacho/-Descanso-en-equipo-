import './style.css';
const root=document.querySelector('#app');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
window.addEventListener('hashchange',()=>{if(location.hash.startsWith('#invitacion='))location.reload();});
const invitation=location.hash.startsWith('#invitacion=')?location.hash.slice(12):null;
// The private token never appears in HTTP URLs or localStorage.
if(invitation)history.replaceState(null,'',location.pathname);
export async function api(path,method='GET',data){
 let response;try{response=await fetch('/api'+path,{method,credentials:'same-origin',headers:data?{'Content-Type':'application/json'}:{},body:data?JSON.stringify(data):undefined});}
 catch{throw Error('No hay conexión con el servidor. No se ha confirmado el guardado. Conserva los datos y vuelve a intentarlo.');}
 let value;try{value=await response.json();}catch{throw Error('El servidor no respondió correctamente. No se ha confirmado el guardado.');}
 if(!response.ok){const e=Error(value.error||'No se pudo completar la solicitud.');e.status=response.status;throw e;}
 return value;
}
const field=(text,name,type='text',extra='')=>`<label class="field"><span>${text}</span><input name="${name}" type="${type}" required ${extra}></label>`;
function shell(title,body){root.innerHTML=`<main class="account-shell"><a class="brand" href="/familia.html">descanso <span class="brand-sub">en equipo</span></a><h1>${title}</h1>${body}<p id="account-error" class="form-error" role="alert"></p><p><a href="/">Abrir demostración local separada</a></p></main>`;}
function bindForm(id,fn){document.querySelector(id).onsubmit=async e=>{e.preventDefault();const b=e.submitter;b.disabled=true;document.querySelector('#account-error').textContent='';try{await fn(Object.fromEntries(new FormData(e.target)));}catch(error){document.querySelector('#account-error').textContent=error.message;}finally{b.disabled=false;}};}
function auth(register=false){
 shell(register?'Crear mi cuenta':'Entrar a mi familia',`<p>Cuenta individual, independiente de ChatGPT. ${invitation?'Hay una invitación pendiente; podrás revisarla después de entrar.':''}</p><form id="auth-form">${register?field('Tu nombre o alias','name','text','maxlength="40" autocomplete="nickname"'):''}${field('Correo electrónico','email','email','autocomplete="username" maxlength="254"')}${field('Contraseña (mínimo 12 caracteres)','password','password',`minlength="12" maxlength="128" autocomplete="${register?'new-password':'current-password'}"`)}<p class="muted">Versión de prueba: todavía no hay recuperación de contraseña ni verificación por correo. No uses tu contraseña de otro servicio.</p><button class="btn">${register?'Crear cuenta':'Entrar'}</button></form><button id="switch-auth" class="text-button">${register?'Ya tengo cuenta':'Crear una cuenta'}</button>`);
 document.querySelector('#switch-auth').onclick=()=>auth(!register);
 bindForm('#auth-form',async b=>{await api(register?'/register':'/login','POST',b);await home();});
}
async function home(){
 const {user}=await api('/session');
 if(invitation){
  shell('Aceptar invitación',`<p>Entraste como ${esc(user.name)} (${esc(user.email)}). El enlace añade tu cuenta a una familia. Acepta solo si reconoces a quien te lo envió.</p><form id="join-form"><button class="btn">Aceptar invitación privada</button></form><button id="logout" class="text-button">Salir de esta cuenta</button>`);
  document.querySelector('#logout').onclick=async()=>{await api('/logout','POST',{});auth();};
  bindForm('#join-form',async()=>{const {id}=await api('/invitations/accept','POST',{token:invitation});await openPlan(id,user);});return;
 }
 const {families}=await api('/families');
 const selected=new URL(location.href).searchParams.get('familia');
 if(selected&&families.some(f=>f.id===selected)){await openPlan(selected,user);return;}
 shell('Tu espacio familiar',`<p>Hola, ${esc(user.name)}. Estos planes se guardan en la base de datos del servidor.</p><div>${families.map(f=>`<p><button class="btn secondary" data-family="${esc(f.id)}">${esc(f.name)}</button></p>`).join('')}</div><h2>Crear una familia</h2><p>El plan empieza vacío. Declara tu disponibilidad en Mi equipo, invita al otro adulto y añade las tareas y descansos desde Plan semanal.</p><form id="family-form">${field('Nombre de la familia','family','text','maxlength="60"')}${field('Zona horaria','zone','text','value="America/La_Paz"')}<button class="btn">Crear familia y configurar plan</button></form><button id="logout" class="text-button">Cerrar sesión</button>`);
 root.querySelectorAll('[data-family]').forEach(b=>b.onclick=()=>openPlan(b.dataset.family,user).catch(e=>document.querySelector('#account-error').textContent=e.message));
 document.querySelector('#logout').onclick=async()=>{await api('/logout','POST',{});auth();};
 bindForm('#family-form',async b=>{const {id}=await api('/families','POST',b);await openPlan(id,user);});
}
async function openPlan(id,user){
 const initial=await api('/families/'+id);
 window.realPlan={user,id,owner:initial.owner,revision:initial.revision,initial:initial.plan,confirmed:structuredClone(initial.plan),api,
  pending:false,failedDraft:null,error:'',status:'Guardado en el servidor',
  async save(plan){
   if(this.pending)throw Error('Espera a que termine el guardado anterior.');
   this.pending=true;this.status='Guardando en el servidor…';
   try{const result=await api('/families/'+id,'PUT',{revision:this.revision,plan});this.revision=result.revision;this.confirmed=structuredClone(result.plan);this.error='';this.status='Guardado en el servidor';}
   catch(e){this.failedDraft=structuredClone(plan);this.error=e.message;this.status='Cambio sin guardar';throw e;}
   finally{this.pending=false;}
  }
 };
 history.replaceState(null,'',location.pathname+'?familia='+encodeURIComponent(id)+'#semana');
 await import('./app.js');
}
try{await home();}catch(e){if(e.status===401)auth();else{shell('No se pudo abrir el espacio familiar','<p>Comprueba que el servidor esté iniciado y vuelve a cargar esta página.</p>');document.querySelector('#account-error').textContent=e.message;}}
