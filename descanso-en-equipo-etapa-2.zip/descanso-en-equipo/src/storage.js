import { STORAGE_KEY, TYPES, validateInterval, conflict } from './planner.js';

// This key is unchanged so existing v1 demo data continues to load.
export const MEMORY_WARNING = 'Sin guardado persistente: los cambios solo están en esta pestaña y se perderán al recargar. Usa «Guardar copia / recuperar» antes de salir.';
const fail = () => { throw new Error('La copia no es un plan de demostración válido. No se ha reemplazado el plan actual.'); };
const text = (s, max=240) => typeof s === 'string' && s.length <= max;
const safeId = s => typeof s === 'string' && /^[A-Za-z0-9_-]{1,100}$/.test(s);
const clockTime = s => typeof s === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(s);
const record = v => v && typeof v === 'object' && !Array.isArray(v);
function peopleValid(people, partial=false) {
  return Array.isArray(people) && people.length > 0 && people.length <= 100 && new Set(people.map(p=>p.id)).size === people.length && people.every(p=>record(p) && safeId(p.id) && text(p.name,40) && (partial || p.name.trim()) && typeof p.babyCare === 'boolean' && Array.isArray(p.availability) && p.availability.every(w=>record(w) && Array.isArray(w.days) && w.days.every(d=>Number.isInteger(d)&&d>=1&&d<=7) && /^([01]\d|2[0-3]):[0-5]\d$/.test(w.start) && /^([01]\d|2[0-3]):[0-5]\d$/.test(w.end)));
}
export function validateState(s) {
  if (!record(s) || s.version !== 1 || !text(s.family,60) || !s.family.trim() || !text(s.zone,100) || !peopleValid(s.people)) fail();
  try { new Intl.DateTimeFormat('es',{timeZone:s.zone}); } catch { fail(); }
  const ids=new Set(s.people.map(p=>p.id));
  const intervals=items=>Array.isArray(items) && items.length<=10000 && new Set(items.map(t=>t.id)).size===items.length && items.every(t=>{
    if(!record(t)||!safeId(t.id)||!text(t.start,100)||!text(t.end,100))return false;
    try {validateInterval(t.start,t.end);return true;}catch{return false;}
  });
  if(!intervals(s.tasks)||!s.tasks.every(t=>TYPES.includes(t.type)&&text(t.description)&&[null,...ids].includes(t.assignee)&&['propuesta','aceptada','realizada','cancelada'].includes(t.status)))fail();
  if(!intervals(s.rests)||!s.rests.every(r=>ids.has(r.person))||!ids.has(s.actor)||!record(s.reviews)||!record(s.wizard)||![1,2,3,4].includes(s.wizard.step))fail();
  if(s.wizard.draft!==null){
    const d=s.wizard.draft;
    if(!record(d)||!text(d.family,60)||!text(d.zone,100)||!peopleValid(d.people,true)||!Array.isArray(d.selected)||!d.selected.every(t=>TYPES.includes(t))||!/^\d{4}-\d{2}-\d{2}$/.test(d.week)||!(d.restStart===''||clockTime(d.restStart))||!(d.restEnd===''||clockTime(d.restEnd))||!(d.restPerson===''||d.people.some(p=>p.id===d.restPerson)))fail();
  }
  const accepted=s.tasks.filter(t=>t.status==='aceptada');
  if(accepted.some(t=>!t.assignee))fail();
  if(accepted.some(t=>conflict(accepted,t)))throw new Error('Hay un cruce entre tareas aceptadas de la misma persona. Ajusta el horario antes de guardar.');
  return s;
}
export function parseBackup(raw) {
  if(typeof raw!=='string'||raw.length>2_000_000)fail();
  let value;try{value=JSON.parse(raw);}catch{fail();}
  try{return validateState(value?.format==='descanso-demo-backup' ? value.plan : value);}catch{fail();}
}
export function backupText(state) {
  return JSON.stringify({format:'descanso-demo-backup',version:1,plan:validateState(state)},null,2);
}
export function createDemoStorage(getStorage) {
  let mode='checking';
  let errorName='';
  let unreadableRaw=null;
  return {
    get mode(){return mode;},
    get errorName(){return errorName;},
    get unreadableRaw(){return unreadableRaw;},
    load(){
      let raw;
      try {
        const storage=getStorage();raw=storage.getItem(STORAGE_KEY);
        if(raw!==null){
          let parsed;
          try { parsed=validateState(JSON.parse(raw)); }
          catch {mode='recovery';unreadableRaw=raw;return null;}
          mode='ready';return parsed;
        }
        // Probe access without replacing an existing plan or any other app's keys.
        const probe=STORAGE_KEY+'.probe';
        try {storage.setItem(probe,'ok');if(storage.getItem(probe)!=='ok')throw new Error('WriteNotRetained');}
        finally {storage.removeItem(probe);}
        mode='ready';return null;
      } catch(error){mode='memory';errorName=error.name;return null;}
    },
    save(state,{replace=false}={}){
      if(mode==='recovery'&&!replace)return false;
      try {
        const json=JSON.stringify(validateState(state));
        const storage=getStorage();
        storage.setItem(STORAGE_KEY,json);
        if(storage.getItem(STORAGE_KEY)!==json)throw new Error('WriteNotRetained');
        mode='ready';errorName='';unreadableRaw=null;return true;
      } catch(error){mode='memory';errorName=error.name;return false;}
    }
  };
}
