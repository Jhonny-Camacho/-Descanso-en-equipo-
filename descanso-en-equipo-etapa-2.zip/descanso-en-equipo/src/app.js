import './style.css';
import { createDemoStorage, MEMORY_WARNING, parseBackup, backupText } from './storage.js';
import { STORAGE_KEY, TYPES, RELAY, DAYS, uid, today, monday, addDays, at, local, dateOf, available, accept, editTask, coverage, affected, propose, copyWeek, relayMessage, seed } from './planner.js';

const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const real=window.realPlan||null;
const demoStorage=createDemoStorage(()=>window.localStorage);
let state=real?structuredClone(real.initial):(demoStorage.load()||seed());
let week = monday(today(state.zone));
let route = location.hash.slice(1) || 'inicio';
let notice = '';
let lastSaveSucceeded=demoStorage.mode==='ready';
let modalCleanup = null;
const icon = (name, size=20) => {
 const shapes = { leaf:'<path d="M20 4C12 2 3 7 5 15c2 7 14 6 15-11Z"/><path d="M5 20 15 9"/>', home:'<path d="m3 10 9-7 9 7v10H3Z"/><path d="M9 20v-7h6v7"/>', calendar:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4m10-4v4M3 11h18m-13 4h2m4 0h2"/>', team:'<circle cx="9" cy="7" r="3"/><path d="M3 21v-4a6 6 0 0 1 12 0v4m2-17a3 3 0 0 1 0 6m1 4a5 5 0 0 1 3 5v2"/>', check:'<path d="m5 12 4 4L19 6"/>', arrow:'<path d="M4 12h16m-6-6 6 6-6 6"/>', heart:'<path d="M20 5c-3-3-7-1-8 1-2-3-6-4-9 0-4 6 9 14 9 14S25 10 20 5Z"/>', sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2"/>', moon:'<path d="M20 15A9 9 0 0 1 9 3a9 9 0 1 0 11 12Z"/>', print:'<path d="M7 8V3h10v5M7 17H3V9h18v8h-4M7 14h10v7H7Z"/>', plus:'<path d="M12 4v16M4 12h16"/>', clock:'<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>', review:'<path d="M7 3h10v3h3v15H4V6h3Z"/><path d="m8 13 3 3 5-6"/>', hand:'<path d="M7 12V5a2 2 0 0 1 4 0v6-8a2 2 0 0 1 4 0v8-6a2 2 0 0 1 4 0v10c0 9-9 9-12 4l-4-6a2 2 0 0 1 3-3l3 4"/>' };
 return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${shapes[name]||shapes.leaf}</svg>`;
};
const person = id => state.people.find(p=>p.id===id)?.name || 'Sin responsable';
const avatar = (id, large=false) => `<span class="avatar ${large?'large':''} tone-${state.people.findIndex(p=>p.id===id)%3}" aria-hidden="true">${esc(person(id).slice(0,1))}</span>`;
const fmtDate = (date, options={weekday:'long',day:'numeric',month:'long'}) => new Intl.DateTimeFormat('es', {...options,timeZone:'UTC'}).format(new Date(date+'T12:00:00Z'));
const time = v => new Intl.DateTimeFormat('es', {hour:'2-digit',minute:'2-digit',hour12:false,timeZone:state.zone}).format(new Date(v));
const interval = t => `${time(t.start)} – ${dateOf(t.start,state.zone)!==dateOf(t.end,state.zone)?fmtDate(dateOf(t.end,state.zone),{day:'numeric',month:'short'})+' · ':''}${time(t.end)}`;
const weekTasks = (w=week) => state.tasks.filter(t=>dateOf(t.start,state.zone)>=w && dateOf(t.start,state.zone)<addDays(w,7)).sort((a,b)=>a.start.localeCompare(b.start));
const options = (list, val) => list.map(([v,n])=>`<option value="${esc(v)}" ${v===val?'selected':''}>${esc(n)}</option>`).join('');
const personOptions = (id, blank=false) => options([...(blank?[['','Sin responsable']]:[]), ...state.people.map(p=>[p.id,p.name])],id);
function persist(options) {
 if(real){
  const pending=real.save(structuredClone(state));
  updateRemoteStatus();
  return pending.then(()=>{lastSaveSucceeded=true;updateRemoteStatus();}).catch(error=>{state=structuredClone(real.confirmed);lastSaveSucceeded=false;updateRemoteStatus();throw error;});
 }
 lastSaveSucceeded=demoStorage.save(state,options);
 return lastSaveSucceeded;
}
function visibleNotice(){
 if(real)return real.error|| (real.pending?'Guardando en el servidor…':notice);
 return notice && !lastSaveSucceeded ? 'Cambio aplicado solo en esta pestaña. No se ha guardado para recargar. Usa «Guardar copia / recuperar».' : notice;
}
function storageStatus(){
 if(real)return remoteStatus();
 const ready=demoStorage.mode==='ready';
 const message=ready?'Almacenamiento local accesible. Se comprueba cada escritura y lectura; cambiar de vista, navegador o archivo puede cambiar el espacio de datos. Conserva una copia del plan.':demoStorage.mode==='recovery'?'Hay datos guardados que no se pudieron leer. No los sobrescribiremos automáticamente. Usa «Guardar copia / recuperar» para conservar el texto original o recuperar una copia válida.':MEMORY_WARNING;
 return `<section id="storage-status" class="storage-status ${ready?'storage-ready':'storage-unavailable'}" role="${ready?'region':'alert'}" aria-label="Estado del almacenamiento" data-mode="${demoStorage.mode}"><div><strong>${ready?'Guardado local en esta vista':demoStorage.mode==='recovery'?'Datos anteriores protegidos':'Solo en esta pestaña · no se conservará al recargar'}</strong><p>${message}</p></div><button class="btn secondary small" data-action="backup">Guardar copia / recuperar</button></section>`;
}
function notify(message) {
 notice=message;const el=$('#notice');if(el){el.textContent=visibleNotice();el.hidden=!el.textContent;}
 const status=$('#storage-status');if(status)status.outerHTML=storageStatus();
}
function go(r) { if (location.hash==='#'+r) { route=r;render(); } else location.hash=r; }
window.addEventListener('hashchange',()=>{route=location.hash.slice(1)||'inicio';render();$('#main-title')?.focus();window.scrollTo(0,0);});
function label(text, content, cls='') {return `<label class="field ${cls}"><span>${text}</span>${content}</label>`;}
function pill(task) { const outside = task.assignee && task.status==='aceptada' && !available(state.people.find(p=>p.id===task.assignee),task,state.zone);return `<span class="pill ${!task.assignee?'uncovered':task.status}">${!task.assignee&&task.status!=='cancelada'?'Sin cobertura':task.status==='propuesta'?'Por confirmar':task.status==='aceptada'?'Aceptada':task.status==='realizada'?'Realizada':'Cancelada'}</span>${outside?'<span class="pill uncovered">Disponibilidad cambió · revisar</span>':''}`; }
function taskCard(t, compact=false) {
 const own=state.actor===t.assignee; const actions=t.status==='propuesta'&&own?`<button class="btn small" data-action="accept" data-id="${t.id}">${icon('check',16)} Aceptar</button><button class="btn small ghost" data-action="reject" data-id="${t.id}">Rechazar</button>`:t.status==='aceptada'&&own?`<button class="btn small secondary" data-action="complete" data-id="${t.id}">Marcar realizada</button>`:'';
 return `<article class="task ${t.status==='cancelada'?'is-cancelled':''}"><div class="task-top"><span class="task-time">${icon('clock',15)} ${interval(t)}</span>${pill(t)}</div><h3>${esc(t.type)}</h3>${t.description?`<p class="task-note">${esc(t.description)}</p>`:''}<div class="task-bottom"><span class="person-line">${t.assignee?avatar(t.assignee):'<span class="empty-avatar">?</span>'}${esc(person(t.assignee))}</span><div class="task-actions">${actions}<button class="icon-button" data-action="edit-task" data-id="${t.id}" aria-label="Editar ${esc(t.type)}">✎</button>${!compact&&t.status!=='cancelada'?`<button class="text-button muted" data-action="cancel-task" data-id="${t.id}" aria-label="Cancelar ${esc(t.type)}">Cancelar</button>`:''}</div></div></article>`;
}
function restCard(r) {const c=coverage(r,state);return `<article class="rest-card"><span class="rest-icon">${icon('moon',24)}</span><div><div class="eyebrow">Descanso previsto para ${esc(person(r.person))}</div><h3>${interval(r)}</h3><p class="${c.label.startsWith('Con ')?'success-text':''}">${c.label.startsWith('Con ')?'✓ ':''}${c.label}${c.task?.status==='aceptada'?` · ${esc(person(c.task.assignee))}`:''}</p></div><button class="icon-button" data-action="delete-rest" data-id="${r.id}" aria-label="Eliminar descanso previsto">×</button></article>`;}
function header(title,subtitle,actions='') {return `<div class="page-heading"><div><p class="eyebrow">${esc(state.family)}</p><h1 id="main-title" tabindex="-1">${title}</h1><p class="muted">${subtitle}</p></div><div class="heading-actions">${actions}</div></div>`;}
function render() {
 if(real&&['inicio','configurar'].includes(route))route='semana';
 const nav=[['hoy','sun','Hoy'],['semana','calendar','Plan semanal'],['equipo','team','Mi equipo'],['revision','review','Revisión semanal']];
 const landing=route==='inicio';
 $('#app').innerHTML=`<a class="skip-link" href="#main-title">Saltar al contenido</a><div class="demo-banner"><span class="demo-dot"></span><strong>${real?'Familia compartida':'Demostración'}</strong><span>${real?'Cuenta individual · datos en el servidor':demoStorage.mode==='ready'?'Guardado local en esta vista. Conserva una copia.':'Solo en esta pestaña: copia el plan antes de recargar.'}</span><button data-action="privacy" class="banner-link">Cómo funciona</button></div><div class="app-shell ${landing?'landing-shell':''}"><aside class="sidebar"><a class="brand" href="#inicio"><span class="brand-symbol">${icon('leaf',27)}</span><span>descanso<span class="brand-sub">en equipo</span></span></a><div class="side-divider"></div><div class="side-family">TU ESPACIO FAMILIAR</div><nav aria-label="Navegación principal">${nav.map(([r,i,n])=>`<a href="#${r}" class="nav-item ${route===r?'active':''}" ${route===r?'aria-current="page"':''}>${icon(i)}<span>${n}</span>${r==='hoy'?'<span class="nav-dot"></span>':''}</a>`).join('')}</nav><div class="side-note">${icon('heart',24)}<p>Cuidar también es<br><strong>dejarse acompañar.</strong></p><span>Un paso a la vez, en equipo.</span></div><div class="sidebar-bottom"><button class="text-button" data-action="wizard">${icon('plus',16)} Configurar mi familia</button><button class="text-button muted" data-action="reset">Reiniciar demostración</button><span class="version">Hecho para compartir la carga</span></div></aside><div class="workspace"><header class="topbar"><span class="topbar-title">${landing?'Un poco de ayuda hace equipo.':esc(state.family)}</span><div class="simulation">${real?`<div class="real-account"><span>${esc(person(state.actor))}</span><button class="text-button" data-action="invitations">Invitaciones</button><button class="text-button" data-action="logout">Salir</button></div>`:label('Simulando a',`<select id="actor" aria-label="Persona que estás simulando">${personOptions(state.actor)}</select>`)}${avatar(state.actor)}</div></header>${storageStatus()}<div id="notice" class="notice" role="status" ${!notice?'hidden':''}>${esc(visibleNotice())}</div><main id="main" class="${landing?'landing-main':''}">${landing?landingPage():route==='hoy'?todayPage():route==='semana'?weekPage():route==='equipo'?teamPage():route==='revision'?reviewPage():route==='configurar'?wizardPage():todayPage()}</main><footer class="app-footer"><span>${icon('leaf',14)} Un plan compartido. Más espacio para ustedes.</span><div class="footer-links"><button class="text-button" data-action="backup">Guardar copia / recuperar</button><button class="text-button" data-action="wizard">Configurar familia</button><button class="text-button" data-action="reset">Reiniciar demo</button><button class="text-button" data-action="privacy">Privacidad y alcance</button></div></footer></div></div><div id="modal-root"></div>`;
 if(real){
  document.querySelectorAll('[data-action="reset"]').forEach(el=>el.remove());
  document.querySelectorAll('[data-action="wizard"]').forEach(el=>el.textContent='Configurar familia');
  document.querySelectorAll('[data-action="edit-person"]').forEach(el=>{if(el.dataset.id!==real.user.id)el.remove();});
  const info=document.querySelector('.team-grid')?.previousElementSibling;
  if(info?.classList.contains('info-box'))info.innerHTML='<p>Cuenta individual: cada adulto declara su disponibilidad y acepta únicamente sus tareas. Para añadir a alguien, envía una invitación privada.</p>';
 }
}
function landingPage() {
 return `<section class="hero"><div class="hero-copy"><span class="overline"><span class="tiny-star">✳</span> LOS CUIDADOS SE COMPARTEN</span><h1 id="main-title" tabindex="-1">Organicen los cuidados.<br><em>Compartan<br class="desktop-break"> la carga.</em></h1><p>Un plan sencillo para saber quién ayuda, cuándo y con qué, sin tener que recordarlo todo.</p><div class="hero-buttons"><a class="btn" href="#hoy">Probar demostración ${icon('arrow',18)}</a><button class="btn secondary" data-action="wizard">Crear mi plan</button></div><span class="hero-footnote">Sin registro. Con datos ficticios. A su ritmo.</span><div class="hero-team"><div class="avatar-stack">${state.people.slice(0,3).map(p=>avatar(p.id)).join('')}</div><span>Para madres, parejas, abuelas<br>y quienes están para ayudar.</span></div></div><div class="hero-visual"><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><span class="floating-leaf leaf-one">${icon('leaf',50)}</span><div class="preview-plan"><div class="preview-plan-head"><span class="mini-logo">${icon('sun',20)}</span><div><span class="eyebrow">UN DÍA, EN EQUIPO</span><h2>Hay un plan para hoy.</h2></div><span class="mini-dots">•••</span></div><div class="preview-date">Lunes <span>· Un ejemplo de su plan</span></div><div class="preview-task"><span class="preview-hour">12:00</span><div><h3>Preparar la comida</h3><span>Elena se encarga</span></div><span class="preview-check">${icon('check',17)}</span></div><div class="preview-rest"><div>${icon('moon',22)}<span>Un momento para Ana</span></div><h3>19:00 – 20:00</h3><p>Descanso previsto</p><span class="pill aceptada">✓ Leo aceptó el relevo</span></div><div class="preview-task last"><span class="preview-hour">20:00</span><div><h3>Preparar los materiales</h3><span>Propuesta para Leo</span></div><span class="small-clock">${icon('clock',18)}</span></div><div class="preview-plan-foot">${icon('heart',15)} Menos por recordar. Más por compartir.</div></div><div class="floating-card">${icon('team',21)}<span>Cada ayuda cuenta.<br><strong>Cada persona confirma.</strong></span></div></div></section><section class="steps-section"><div class="section-kicker">SENCILLO, DESDE EL PRINCIPIO</div><h2>De “¿quién puede?” a “yo me encargo”.</h2><div class="steps-grid">${[['01','team','Añadan a su equipo','Cada adulto indica cuándo puede ayudar. También con la comida, la casa o las compras.'],['02','calendar','Repartan los cuidados','Armen un plan semanal que respete sus horarios y deje a la vista lo que falta cubrir.'],['03','check','Confirmen el plan','Cada persona acepta sus tareas. Todos pueden consultar qué les corresponde hoy.']].map(([n,i,t,d])=>`<article><div class="step-top"><span class="step-icon">${icon(i,23)}</span><span class="step-number">${n}</span></div><h3>${t}</h3><p>${d}</p></article>`).join('')}</div></section><section class="gentle-strip">${icon('leaf',27)}<div><h2>Organización para cuidar a quienes cuidan.</h2><p>Un descanso previsto es un acuerdo por organizar; no una promesa de horas dormidas.</p></div></section><section class="faq"><div><span class="section-kicker">ANTES DE EMPEZAR</span><h2>Unas dudas, resueltas.</h2><p class="muted">Con expectativas claras y sin complicaciones.</p></div><div>${[['¿Necesitamos que todos cuiden al bebé?','No. El equipo también puede preparar comida, hacer compras u ordenar la casa mientras la madre atiende al bebé. Solo una persona que pueda asumir el cuidado del bebé puede cubrir un relevo.'],['¿Los cambios se ven en otros teléfonos?','En esta demostración, no. Intentamos guardar en el almacenamiento de esta vista; si está bloqueado, solo conservamos cambios en la pestaña y necesitas una copia para recuperarlos. Las cuentas, invitaciones privadas y sincronización llegarán en la etapa 2.'],['¿Qué datos necesitan?','Solo alias, disponibilidad y tareas. No pedimos información del bebé ni datos clínicos. Eviten incluir datos clínicos en las notas. No usamos analítica.'],['¿Esto hará que nuestro bebé duerma más?','No prometemos cambios en el sueño del bebé ni horas de descanso. La aplicación ayuda a coordinar responsabilidades familiares y no ofrece recomendaciones médicas.']].map(([q,a])=>`<details><summary>${q}<span aria-hidden="true">+</span></summary><p>${a}</p></details>`).join('')}</div></section>`;
}
function todayPage() {
 const date=today(state.zone), tasks=state.tasks.filter(t=>dateOf(t.start,state.zone)===date).sort((a,b)=>a.start.localeCompare(b.start));
 const pending=tasks.filter(t=>t.status!=='cancelada'&&t.status!=='realizada');
 const next=pending.find(t=>new Date(t.end)>new Date());
 const rests=state.rests.filter(r=>dateOf(r.start,state.zone)===date);
 return `${header('Hoy, nos cuidamos en equipo.', `${fmtDate(date)} · ${state.zone}`,`<button class="btn secondary" data-action="relay">${icon('hand',18)} Necesito un relevo</button>`)}<div class="welcome-note">${icon('leaf',20)}<span>Cada responsabilidad confirmada es algo menos por recordar.</span><a href="#semana">Ver plan semanal ${icon('arrow',16)}</a></div><div class="stats-row"><div><span class="stat-icon">${icon('calendar',20)}</span><strong>${tasks.filter(t=>t.status!=='cancelada').length}</strong><span>Tareas de hoy</span></div><div><span class="stat-icon peach">${icon('clock',20)}</span><strong>${tasks.filter(t=>t.status==='propuesta').length}</strong><span>Por confirmar</span></div><div><span class="stat-icon lavender">${icon('moon',20)}</span><strong>${rests.length}</strong><span>Descansos previstos</span></div></div><div class="today-grid"><section><div class="section-heading"><h2>${icon('sun',21)} El siguiente paso</h2><button class="text-button" data-action="new-task">+ Añadir tarea</button></div>${next?taskCard(next):empty('No hay próximas tareas para hoy.','Revisa los pendientes de hoy o prepara el plan semanal.')}<div class="section-heading lower"><h2>Las demás tareas de hoy</h2><span class="muted">${tasks.filter(t=>t!==next).length} tareas</span></div><div class="task-list">${tasks.filter(t=>t!==next).map(t=>taskCard(t)).join('')||'<p class="empty-small">No hay más tareas para hoy.</p>'}</div></section><aside class="right-column"><div class="section-heading"><h2>${icon('moon',21)} Espacio para descansar</h2><button class="text-button" data-action="new-rest">Añadir</button></div>${rests.map(restCard).join('')||empty('Todavía no hay un bloque.','Pueden reservar un momento y acordar su cobertura.')}<p class="rest-disclaimer">El descanso es previsto. La cobertura solo está confirmada cuando otro adulto acepta el relevo. Mantengan siempre acordado quién atiende al bebé.</p><div class="team-widget"><div class="section-heading"><h2>Tu equipo, cerca</h2><a href="#equipo" class="text-button">Ver equipo</a></div>${state.people.map(p=>`<div class="team-row">${avatar(p.id)}<div><strong>${esc(p.name)}</strong><span>${p.babyCare?'Cuidados y apoyo':'Apoyo doméstico'}</span></div><span class="team-count">${tasks.filter(t=>t.assignee===p.id&&t.status==='aceptada').length} aceptadas</span></div>`).join('')}</div></aside></div>`;
}
const empty=(t,d)=>`<div class="empty-state">${icon('leaf',30)}<h3>${t}</h3><p>${d}</p></div>`;
function weekPage() {
 const tasks=weekTasks();
 return `${header('Un plan para compartir.', 'Cada propuesta necesita la confirmación de su responsable.',`<button class="btn secondary" data-action="print">${icon('print',17)} Imprimir / PDF</button>${real?'<button class="btn secondary" data-action="new-rest">Añadir descanso previsto</button>':''}<button class="btn" data-action="new-task">${icon('plus',17)} Añadir tarea</button>`)}<div class="week-toolbar"><div class="week-switch"><button class="icon-button" data-action="prev-week" aria-label="Semana anterior">←</button><h2>${fmtDate(week,{day:'numeric',month:'short'})} — ${fmtDate(addDays(week,6),{day:'numeric',month:'short',year:'numeric'})}</h2><button class="icon-button" data-action="next-week" aria-label="Semana siguiente">→</button><button class="text-button" data-action="current-week">Esta semana</button></div><button class="btn secondary small" data-action="copy-week">Copiar semana anterior</button></div><div class="plan-legend"><span class="pill propuesta">${tasks.filter(t=>t.status==='propuesta'&&t.assignee).length} por confirmar</span><span class="pill aceptada">${tasks.filter(t=>t.status==='aceptada').length} aceptadas</span><span class="pill uncovered">${tasks.filter(t=>!t.assignee&&t.status!=='cancelada').length} sin cobertura</span><span class="muted">Zona horaria: ${esc(state.zone)}</span></div><div class="week-grid">${Array.from({length:7},(_,i)=>{const d=addDays(week,i);return `<section class="day-column ${d===today(state.zone)?'is-today':''}"><div class="day-heading"><h2>${DAYS[i]} <strong>${d.slice(-2)}</strong></h2>${d===today(state.zone)?'<span>Hoy</span>':''}</div>${tasks.filter(t=>dateOf(t.start,state.zone)===d).map(t=>taskCard(t,true)).join('')||'<div class="day-empty">Un día por organizar.</div>'}${state.rests.filter(r=>dateOf(r.start,state.zone)===d).map(restCard).join('')}<button class="add-day" data-action="new-task" data-date="${d}">+ Añadir tarea</button></section>`}).join('')}</div><section class="print-summary"><h1>${esc(state.family)} · Plan semanal</h1><p>${week} — ${addDays(week,6)} · ${esc(state.zone)}</p><p>${real?'Plan familiar compartido.':'Demostración local.'} Cada persona debe confirmar sus propuestas. Los descansos son previstos.</p><table><thead><tr><th>Día</th><th>Horario</th><th>Tarea</th><th>Responsable</th><th>Estado</th></tr></thead><tbody>${tasks.map(t=>`<tr><td>${fmtDate(dateOf(t.start,state.zone),{weekday:'short',day:'numeric',month:'short'})}</td><td>${interval(t)}</td><td>${esc(t.type)}${t.description?` · ${esc(t.description)}`:''}</td><td>${esc(person(t.assignee))}</td><td>${!t.assignee&&t.status!=='cancelada'?'Sin cobertura':t.status}</td></tr>`).join('')}</tbody></table><h2>Descansos previstos</h2>${state.rests.filter(r=>dateOf(r.start,state.zone)>=week&&dateOf(r.start,state.zone)<addDays(week,7)).map(r=>`<p>${fmtDate(dateOf(r.start,state.zone),{day:'numeric',month:'short'})} · ${interval(r)} · ${esc(person(r.person))} · ${coverage(r,state).label}</p>`).join('')}</section>`;
}
function availabilityText(p) {return p.availability.map(w=>`${w.days.map(d=>DAYS[d-1].slice(0,3)).join(', ')} · ${w.start}–${w.end}${w.end<=w.start?' (+1 día)':''}`).join(' / ')||'Sin disponibilidad declarada';}
function teamPage() {return `${header('Nadie tiene que recordarlo todo.',`Disponibilidad y acuerdos · ${esc(state.zone)}`, '<button class="btn" data-action="add-person">+ Añadir adulto</button>')}<div class="info-box">${icon('team',21)}<p>Estás simulando a <strong>${esc(person(state.actor))}</strong>. Cambia de persona arriba para probar su aceptación. Las cuentas e invitaciones reales se incorporarán en la etapa 2.</p></div><div class="team-grid">${state.people.map(p=>{const tasks=weekTasks().filter(t=>t.assignee===p.id&&t.status==='aceptada');return `<article class="person-card"><div class="person-card-top">${avatar(p.id,true)}<div><h2>${esc(p.name)}</h2><span class="muted">${p.babyCare?'Puede asumir relevos del bebé':'Ayuda doméstica y compañía'}</span></div></div><div class="person-availability"><span class="eyebrow">DISPONIBILIDAD SEMANAL</span><p>${esc(availabilityText(p))}</p></div><h3>${tasks.length} responsabilidades aceptadas esta semana</h3>${tasks.map(t=>`<div class="accepted-line">${icon('check',16)}<span>${esc(t.type)}<small>${fmtDate(dateOf(t.start,state.zone),{weekday:'short',day:'numeric'})} · ${interval(t)}</small></span></div>`).join('')||'<p class="muted">Aún no hay compromisos aceptados.</p>'}<button class="btn secondary full" data-action="edit-person" data-id="${p.id}">Editar disponibilidad</button></article>`}).join('')}</div>`;}
function reviewPage() {
 const tasks=weekTasks(), count=s=>tasks.filter(t=>t.status===s).length, unanswered=tasks.filter(t=>t.status==='propuesta');
 return `${header('Revisar, conversar, ajustar.', 'Una mirada a la semana, sin comparaciones ni reproches.')}<div class="week-toolbar"><div class="week-switch"><button class="icon-button" data-action="prev-week" aria-label="Semana anterior">←</button><h2>${fmtDate(week,{day:'numeric',month:'short'})} — ${fmtDate(addDays(week,6),{day:'numeric',month:'short'})}</h2><button class="icon-button" data-action="next-week" aria-label="Semana siguiente">→</button></div><button class="btn" data-action="adjust-next">Ajustar la próxima semana ${icon('arrow',17)}</button></div><div class="stats-row"><div><strong>${count('realizada')}</strong><span>Tareas realizadas</span></div><div><strong>${unanswered.length}</strong><span>Propuestas sin aceptar</span></div><div><strong>${count('cancelada')}</strong><span>Tareas canceladas</span></div></div><div class="today-grid"><section><h2>Lo que quedó por acordar</h2><p class="muted">Pueden cambiar horarios, pedir apoyo o quitar lo que no sea necesario.</p><div class="task-list">${unanswered.map(t=>taskCard(t)).join('')||empty('Todo conversado.','No hay propuestas pendientes esta semana.')}</div></section><aside><form id="review-form" class="person-card"><span class="step-icon">${icon('heart',25)}</span><h2>¿Este reparto les resultó útil?</h2><p class="muted">Responder es opcional. ${real?'Se guarda en el plan compartido.':'Solo se guarda en este dispositivo.'}</p>${label('Su respuesta',`<select name="answer">${options([['','Prefiero no responder'],['si','Sí, nos ayudó'],['parte','En parte; queremos ajustarlo'],['no','Necesitamos otro reparto']],state.reviews[week]||'')}</select>`)}<button class="btn full">Guardar revisión</button></form></aside></div>`;
}
function draft() {return state.wizard.draft;}
function ensureWizard() {if(!draft())state.wizard={step:1,draft:{family:'',zone:state.zone,people:[{id:uid(),name:'',babyCare:true,availability:[{days:[1,2,3,4,5],start:'09:00',end:'13:00'}]}],selected:[TYPES[1],TYPES[2]],restPerson:'',restStart:'19:00',restEnd:'20:00',week:monday(today(state.zone))}};persist();}
function startWizard(){ensureWizard();go('configurar');}
function wizardPerson(p,i) {const w=p.availability[0]||{days:[],start:'09:00',end:'13:00'};return `<fieldset class="wizard-person"><legend>Adulto ${i+1}</legend><div class="two-cols">${label('Nombre o alias',`<input name="person-name-${i}" value="${esc(p.name)}" maxlength="40" required autocomplete="off">`)}<label class="check-label"><input type="checkbox" name="person-baby-${i}" ${p.babyCare?'checked':''}> Puede asumir relevos del bebé</label></div><p class="muted small-text">Desmarca esta opción si solo ayudará con la casa, comida o compañía.</p><div class="day-checks">${DAYS.map((d,j)=>`<label><input type="checkbox" name="person-days-${i}" value="${j+1}" ${w.days.includes(j+1)?'checked':''}><span>${d.slice(0,3)}</span></label>`).join('')}</div><div class="two-cols">${label('Disponible desde',`<input type="time" name="person-start-${i}" value="${w.start}" required>`)}${label('Disponible hasta',`<input type="time" name="person-end-${i}" value="${w.end}" required>`)}</div><p class="small-text muted">Si el fin es anterior o igual al inicio, termina al día siguiente. Luego podrás añadir más franjas en Mi equipo.</p>${i?`<button type="button" class="text-button" data-action="wizard-remove-person" data-index="${i}">Quitar adulto</button>`:''}</fieldset>`;}
function wizardPage() {
 if(!draft())ensureWizard();
 const s=state.wizard.step,d=draft();
 let fields='';
 if(s===1)fields=`<h2>Un nombre para su equipo.</h2><p class="muted">Puede configurarlo cualquier adulto. No necesitamos datos del bebé.</p>${label('Nombre o alias de la familia',`<input name="family" value="${esc(d.family)}" required maxlength="60" placeholder="Por ejemplo, Equipo de casa" autocomplete="off">`)}${label('Zona horaria',`<input name="zone" list="timezones" value="${esc(d.zone)}" required><datalist id="timezones">${['America/La_Paz','America/Mexico_City','America/Bogota','America/Lima','America/Santiago','America/Argentina/Buenos_Aires','Europe/Madrid','UTC'].map(z=>`<option>${z}</option>`).join('')}</datalist>`)}${label('Semana que quieren organizar',`<input name="week" type="date" value="${d.week}" required>`)}<p class="muted small-text">Usamos la semana del lunes al domingo que contiene esta fecha.</p>`;
 if(s===2)fields=`<h2>¿Con quién cuentan?</h2><p class="muted">Añadan adultos, sus horarios y el tipo de ayuda que pueden asumir.</p>${d.people.map(wizardPerson).join('')}<button type="button" class="btn secondary" data-action="wizard-add-person">+ Añadir otro adulto</button>`;
 if(s===3)fields=`<h2>¿Qué les vendría bien compartir?</h2><p class="muted">Crearemos una propuesta diaria por tarea a partir de las 10:00. Después podrán editar cada fecha y horario.</p><div class="catalog">${TYPES.filter(t=>t!==RELAY&&t!==TYPES[9]).map(t=>`<label class="catalog-option"><input type="checkbox" name="selected" value="${esc(t)}" ${d.selected.includes(t)?'checked':''}><span>${esc(t)}</span></label>`).join('')}</div><p class="muted">Pueden crear tareas personalizadas y relevos desde el plan semanal.</p>`;
 if(s===4)fields=`<h2>Hagan espacio para una pausa.</h2><p class="muted">Añadiremos un descanso previsto cada día y propondremos un relevo a otro adulto disponible. Si nadie puede, quedará sin cobertura confirmada.</p>${label('¿Para quién es el descanso?',`<select name="restPerson">${options(d.people.map(p=>[p.id,p.name]),d.restPerson||d.people[0].id)}</select>`)}<div class="two-cols">${label('Desde',`<input name="restStart" type="time" value="${d.restStart}" required>`)}${label('Hasta',`<input name="restEnd" type="time" value="${d.restEnd}" required>`)}</div><p class="muted small-text">Si el fin es anterior o igual al inicio, el bloque termina al día siguiente. El descanso previsto no equivale a horas dormidas.</p><div class="info-box">${icon('leaf',20)}<p>Demostración local: el plan reemplazará los datos actuales solo después de tu confirmación. No crea cuentas ni comparte datos.</p></div>`;
 return `${header('Su familia, su manera de organizarse.','Configurador de demostración · Pueden guardar y continuar después.')}<div class="wizard-layout"><aside class="wizard-steps">${['Su familia','El equipo','Las tareas','El descanso'].map((n,i)=>`<div class="wizard-step ${s===i+1?'current':''}"><span>${s>i+1?'✓':i+1}</span><div><small>PASO ${i+1}</small><strong>${n}</strong></div></div>`).join('')}<p>Lo necesario para empezar.<br>Lo demás, sobre la marcha.</p></aside><form id="wizard-form" class="wizard-card" data-step="${s}">${fields}<p id="wizard-error" class="form-error" role="alert"></p><div class="wizard-buttons">${s>1?'<button type="button" class="btn secondary" data-action="wizard-back">Atrás</button>':''}<button type="button" class="text-button" data-action="wizard-save">Guardar y continuar después</button><button class="btn">${s===4?'Generar mi plan':'Continuar'} ${icon('arrow',16)}</button></div></form></div>`;
}
function readWizard(validate=true) {
 const f=$('#wizard-form');if(!f)return;
 if(validate&&!f.reportValidity())throw Error('Completa los campos indicados.');
 const data=new FormData(f),d=draft(),s=state.wizard.step;
 if(s===1){const zone=data.get('zone').trim();if(validate)today(zone);d.family=data.get('family').trim();if(validate&&!d.family)throw Error('Escribe un alias para la familia.');d.zone=zone;d.week=monday(data.get('week'));}
 if(s===2){d.people=d.people.map((p,i)=>({...p,name:data.get(`person-name-${i}`).trim(),babyCare:data.has(`person-baby-${i}`),availability:[{days:data.getAll(`person-days-${i}`).map(Number),start:data.get(`person-start-${i}`),end:data.get(`person-end-${i}`)}]}));if(validate&&d.people.some(p=>!p.name))throw Error('Cada adulto necesita un nombre o alias.');}
 if(s===3)d.selected=data.getAll('selected');
 if(s===4){d.restPerson=data.get('restPerson');d.restStart=data.get('restStart');d.restEnd=data.get('restEnd');}
 persist();
}
function generateFamily() {
 const d=draft(); const tasks=[],rests=[];
 for(let day=0;day<7;day++){
  const date=addDays(d.week,day);
  d.selected.forEach((type,i)=>{const h=String(10+i).padStart(2,'0');tasks.push({id:uid(),start:at(`${date}T${h}:00`,d.zone),end:at(`${date}T${h}:45`,d.zone),type,description:''});});
  const endDate=d.restEnd<=d.restStart?addDays(date,1):date;
  const rest={id:uid(),person:d.restPerson,start:at(`${date}T${d.restStart}`,d.zone),end:at(`${endDate}T${d.restEnd}`,d.zone)};rests.push(rest);
  tasks.push({id:uid(),type:RELAY,start:rest.start,end:rest.end,beneficiary:d.restPerson,description:`Relevo durante el descanso de ${d.people.find(p=>p.id===d.restPerson).name}`});
 }
 const proposed=propose(tasks,d.people,d.zone);
 return {version:1,family:d.family,zone:d.zone,people:d.people,tasks:proposed,rests,actor:d.people[0].id,wizard:{step:1,draft:null},reviews:{},custom:true};
}
function dialog(title,body,onSubmit=null,extra='') {
 closeDialog(); const root=$('#modal-root');root.innerHTML=`<dialog aria-labelledby="dialog-title"><form id="dialog-form"><div class="dialog-head"><h2 id="dialog-title">${title}</h2><button type="button" class="icon-button" data-action="close" aria-label="Cerrar ventana">×</button></div>${body}<p class="form-error" id="dialog-error" role="alert"></p>${extra||'<div class="dialog-buttons"><button type="button" class="btn secondary" data-action="close">Volver</button><button class="btn">Guardar</button></div>'}</form></dialog>`;
 const dlg=root.querySelector('dialog');dlg.showModal();
 dlg.addEventListener('close',()=>dlg.remove(),{once:true});
 if(onSubmit){
  const form=root.querySelector('#dialog-form');
  let submitting=false;
  const errorMessage=form.querySelector('#dialog-error');
  errorMessage.tabIndex=-1;
  function showError(message){
   errorMessage.textContent=message;
   errorMessage.focus();
   errorMessage.scrollIntoView({block:'nearest'});
  }
  async function saveForm(){
   if(submitting)return;
   errorMessage.textContent='';
   // Keep native required/type/step validation, with an inline error as well.
   if(!form.reportValidity()){
    const invalid=form.querySelector(':invalid');
    const name=invalid?.labels?.[0]?.querySelector('span')?.textContent;
    showError(`${name?name+': ':''}${invalid?.validationMessage||'Revisa los campos indicados.'}`);
    return;
   }
   try {submitting=true;const buttons=[...form.querySelectorAll('button[type=submit],button:not([type])')];buttons.forEach(b=>b.disabled=true);try{await onSubmit(new FormData(form));}finally{submitting=false;buttons.forEach(b=>b.disabled=false);}}
   catch(error){showError(error.message.includes('Invalid')?'Revisa las fechas y la zona horaria.':error.message);}
  }
  // The demo only saves locally. Handle button activation before the browser
  // attempts native submission, which an embedded preview may disallow.
  form.addEventListener('click',e=>{
   const button=e.target.closest('button');
   if(button?.form===form&&button.type==='submit'){
    e.preventDefault();
    saveForm();
   }
  });
  form.addEventListener('submit',e=>{e.preventDefault();saveForm();});
 }
 modalCleanup=()=>dlg.close();
}
function closeDialog(){if(modalCleanup){const cb=modalCleanup;modalCleanup=null;cb();}}
function confirmDialog(title,message,callback,button='Confirmar') {dialog(title,`<p>${message}</p>`,async()=>{await callback();closeDialog();},`<div class="dialog-buttons"><button type="button" class="btn secondary" data-action="close">Volver</button><button class="btn">${button}</button></div>`);}
function taskDialog(id=null,date=null) {
 const old=state.tasks.find(t=>t.id===id); const day=date||today(state.zone);
 const task=old||{id:uid(),type:TYPES[1],description:'',start:at(day+'T12:00',state.zone),end:at(day+'T13:00',state.zone),assignee:'',status:'propuesta'};
 dialog(old?'Editar tarea':'Una ayuda para el equipo',`${label('Tipo de tarea',`<select name="type">${options(TYPES.map(t=>[t,t]),task.type)}</select>`)}${label('Descripción o nombre personalizado (opcional)',`<input name="description" value="${esc(task.description)}" maxlength="240">`)}<p class="muted small-text">No incluyas información clínica en las notas.</p><div class="two-cols">${label('Inicio · fecha y hora',`<input name="start" type="datetime-local" value="${local(task.start,state.zone)}" required>`)}${label('Fin · fecha y hora',`<input name="end" type="datetime-local" value="${local(task.end,state.zone)}" required>`)}</div><p class="muted small-text">Zona horaria: ${esc(state.zone)}. Para turnos de noche, indica el día siguiente en la fecha de fin.</p>${label('Responsable propuesto',`<select name="assignee">${personOptions(task.assignee||'',true)}</select>`)}<div class="info-box"><p>Cambiar la tarea, el horario o el responsable requiere una nueva confirmación. Solo se permiten propuestas dentro de la disponibilidad declarada.</p></div>`,async data=>{
  const t=editTask(state,{...task,type:data.get('type'),description:data.get('description').trim(),start:at(data.get('start'),state.zone),end:at(data.get('end'),state.zone),assignee:data.get('assignee')||null});
  if(t.type===TYPES[9]&&!t.description)throw Error('Describe la tarea personalizada.');
  state.tasks=old?state.tasks.map(x=>x.id===id?t:x):[...state.tasks,t];await persist();closeDialog();notice='Tarea guardada. Los cambios quedan como propuesta para confirmar.';render();
 });
}
function personDialog(id=null) {
 const old=state.people.find(p=>p.id===id),p=old||{id:uid(),name:'',babyCare:false,availability:[{days:[1,2,3,4,5],start:'09:00',end:'13:00'}]};
 let windows=structuredClone(p.availability);if(!windows.length)windows=[{days:[],start:'09:00',end:'13:00'}];
 function show(draftPerson=p){
 dialog(old?'Editar disponibilidad':'Añadir adulto',`${label('Nombre o alias',`<input name="name" value="${esc(draftPerson.name)}" required maxlength="40">`)}<label class="check-label"><input name="babyCare" type="checkbox" ${draftPerson.babyCare?'checked':''}> Puede asumir relevos del bebé</label><p class="muted">Cada franja se repite semanalmente en ${esc(state.zone)}.</p>${windows.map((w,i)=>`<fieldset class="availability-window"><legend>Franja ${i+1}</legend><div class="day-checks">${DAYS.map((d,j)=>`<label><input type="checkbox" name="days-${i}" value="${j+1}" ${w.days.includes(j+1)?'checked':''}><span>${d.slice(0,3)}</span></label>`).join('')}</div><div class="two-cols">${label('Desde',`<input type="time" name="start-${i}" required value="${w.start}">`)}${label('Hasta',`<input type="time" name="end-${i}" required value="${w.end}">`)}</div></fieldset>`).join('')}<button type="button" class="text-button" id="add-window">+ Añadir franja</button><p class="small-text muted">Para quitar una franja, desmarca todos sus días. Si el fin es anterior o igual al inicio, termina al día siguiente.</p><div class="info-box"><p>Si el cambio afecta tareas aceptadas, te avisaremos antes de guardarlo. Nunca se reasignan automáticamente.</p></div>`,async data=>{
  const updated=read(data);
  const affectedTasks=affected(state,updated);
  const commit=async()=>{state.people=old?state.people.map(x=>x.id===id?updated:x):[...state.people,updated];await persist();notice=affectedTasks.length?`${affectedTasks.length} compromisos aceptados requieren revisión. Conservan su responsable y se señalan en el plan.`:'Disponibilidad guardada.';closeDialog();render();};
  if(affectedTasks.length)confirmDialog('Hay compromisos que revisar',`Este cambio afecta ${affectedTasks.length} tareas aceptadas: ${affectedTasks.slice(0,4).map(t=>esc(t.type)+' · '+fmtDate(dateOf(t.start,state.zone),{day:'numeric',month:'short'})).join('; ')}. Se conservarán, con una advertencia visible. ¿Guardar el cambio?`,commit,'Guardar y señalar');else return commit();
 });
 function read(data){return {...p,name:data.get('name').trim(),babyCare:data.has('babyCare'),availability:windows.map((_,i)=>({days:data.getAll(`days-${i}`).map(Number),start:data.get(`start-${i}`),end:data.get(`end-${i}`)})).filter(w=>w.days.length)};}
 $('#add-window').onclick=()=>{const updated=read(new FormData($('#dialog-form')));windows=updated.availability;windows.push({days:[],start:'18:00',end:'22:00'});show(updated);};
 }
 show();
}
function restDialog() {
 const day=today(state.zone);
 dialog('Reservar un descanso previsto',`${label('Persona que descansaría',`<select name="person">${personOptions(state.actor)}</select>`)}<div class="two-cols">${label('Inicio',`<input name="start" type="datetime-local" value="${day}T19:00" required>`)}${label('Fin',`<input name="end" type="datetime-local" value="${day}T20:00" required>`)}</div><p class="muted">Zona: ${esc(state.zone)}. Este bloque no crea cobertura. Añade un relevo al plan y pide que otro adulto lo confirme.</p>`,async data=>{
 const r={id:uid(),person:data.get('person'),start:at(data.get('start'),state.zone),end:at(data.get('end'),state.zone)};relayMessage(r,state);state.rests.push(r);await persist();closeDialog();notice='Descanso previsto añadido. Revisa su cobertura con el equipo.';render();
 });
}
function backupDialog(){
 dialog('Guardar copia / recuperar',`<p>Conserva una copia antes de recargar o cambiar de vista. Incluye tareas, aceptación, descansos y configuración. No se envía a ningún servidor. Evita datos clínicos y guarda el texto en un lugar privado.</p>${label('Copia del plan actual',`<textarea id="backup-export" readonly rows="5" spellcheck="false">${esc(backupText(state))}</textarea>`)}<button type="button" class="btn secondary" id="copy-backup">Copiar copia del plan</button><p id="backup-copy-result" role="status"></p>${demoStorage.unreadableRaw!==null?label('Texto anterior sin modificar (conservar antes de reemplazar)',`<textarea readonly rows="3">${esc(demoStorage.unreadableRaw)}</textarea>`):''}<hr>${label('Pega aquí una copia para recuperarla','<textarea name="backup" rows="5" spellcheck="false" placeholder="Pega el texto completo de una copia anterior"></textarea>')}<p>Se valida antes de reemplazar el plan y se pide confirmación. Si esta vista bloquea el almacenamiento, la copia recuperada también quedará solo en esta pestaña.</p>`,data=>{
  const recovered=parseBackup(data.get('backup'));
  confirmDialog('¿Recuperar esta copia?',`Reemplazará el plan de esta pestaña por ${esc(recovered.family)}: ${recovered.tasks.length} tareas y ${recovered.rests.length} descansos. ${demoStorage.mode==='ready'?'Intentaremos guardarlo y verificaremos la lectura.':'El almacenamiento no está disponible o requiere recuperación: revisa el aviso de guardado después de recuperar.'}`,()=>{
   state=recovered;week=monday(today(state.zone));persist({replace:true});notice='Copia recuperada y guardada en esta vista.';go('semana');
  },'Reemplazar con esta copia');
 },'<div class="dialog-buttons"><button type="button" class="btn secondary" data-action="close">Cerrar</button><button class="btn" type="submit">Revisar recuperación</button></div>');
 $('#copy-backup').onclick=async()=>{
  const input=$('#backup-export');const result=$('#backup-copy-result');
  input.focus();input.select();
  try{await navigator.clipboard.writeText(input.value);result.textContent='Texto copiado. Pégalo en un archivo o nota privada; esta acción no guarda un archivo automáticamente.';}
  catch{result.textContent='Texto seleccionado. Usa Copiar en tu dispositivo o Ctrl/Cmd+C y pégalo en un archivo o nota privada. La copia automática no está disponible.';}
 };
}
function relayDialog() {
 const tasks=state.tasks.filter(t=>dateOf(t.start,state.zone)>=today(state.zone)&&t.status!=='cancelada'&&t.status!=='realizada');
 const date=today(state.zone);
 dialog('Pedir un relevo',`${label('Pedir ayuda para',`<select name="task"><option value="">Un intervalo personalizado</option>${options(tasks.map(t=>[t.id,`${dateOf(t.start,state.zone)} · ${interval(t)} · ${t.type}`]),'')}</select>`)}<div class="two-cols">${label('Inicio del intervalo',`<input name="start" type="datetime-local" value="${date}T19:00" required>`)}${label('Fin del intervalo',`<input name="end" type="datetime-local" value="${date}T20:00" required>`)}</div>${label('Nota opcional', '<textarea name="note" maxlength="240" rows="2" placeholder="Por ejemplo: ¿alguien puede acompañarme?"></textarea>')}<p class="muted small-text">No incluyas datos clínicos. Nada se envía automáticamente.</p>`,data=>{
 const task=state.tasks.find(t=>t.id===data.get('task'));
 const message=relayMessage({task,start:task?.start||at(data.get('start'),state.zone),end:task?.end||at(data.get('end'),state.zone),note:data.get('note').trim()},state);
 dialog('Mensaje listo para revisar',`${label('Mensaje preparado',`<textarea id="relay-text" readonly rows="8">${esc(message)}</textarea>`)}<p class="muted small-text">Abrir WhatsApp o copiar no envía el mensaje ni confirma un relevo. No incluye enlaces ni sincroniza datos.</p><div class="share-actions"><a class="btn" id="whatsapp" href="https://wa.me/?text=${encodeURIComponent(message)}" target="_blank" rel="noopener noreferrer">Abrir WhatsApp</a><button class="btn secondary" type="button" id="copy-message">Copiar mensaje</button></div><p id="copy-result" role="status"></p>`,null,'<div class="dialog-buttons"><button class="btn secondary" type="button" data-action="close">Cerrar</button></div>');
 $('#copy-message').onclick=async()=>{try{await navigator.clipboard.writeText(message);$('#copy-result').textContent='Mensaje copiado. Tú decides cuándo y a quién enviarlo.';}catch{$('#relay-text').focus();$('#relay-text').select();$('#copy-result').textContent='Seleccionamos el texto. Usa la opción Copiar de tu dispositivo o Ctrl/Cmd+C.';}};
 },'<div class="dialog-buttons"><button type="button" class="btn secondary" data-action="close">Volver</button><button class="btn">Preparar mensaje</button></div>');
 const select=$('[name="task"]');select.onchange=()=>{const t=state.tasks.find(t=>t.id===select.value);for(const name of ['start','end']){const input=$(`[name="${name}"]`);input.disabled=!!t;if(t)input.value=local(t[name],state.zone);}};
}
const actions={
 'close':closeDialog,
 'backup':backupDialog,
 'wizard':startWizard,
 'privacy':()=>dialog('Una demostración, con límites claros.','<p>Esta demo intenta guardar en el almacenamiento de esta vista. Si el navegador lo bloquea, solo mantiene cambios en la pestaña y muestra un aviso. Puedes copiar y recuperar el plan con «Guardar copia / recuperar». No hay cuentas, invitaciones, sincronización ni analítica.</p><p>Usa alias y evita datos clínicos en las notas. Si compartes un mensaje, el contenido pasa al servicio que elijas. Abrir WhatsApp no confirma un compromiso.</p><p>Ayudamos a organizar cuidados; no prometemos horas de sueño ni ofrecemos asesoramiento médico. No es una herramienta de urgencias.</p>',null,'<div class="dialog-buttons"><button type="button" class="btn" data-action="close">Entendido</button></div>'),
 'reset':()=>confirmDialog('¿Reiniciar la demostración?','Se borrarán únicamente los datos locales de Descanso en equipo en este navegador y se recuperará la familia ficticia. Esta acción no afecta a otras aplicaciones.',()=>{state=seed();week=monday(today(state.zone));persist({replace:true});notice='Demostración reiniciada con la familia ficticia.';go('hoy');},'Reiniciar datos de demo'),
 'new-task':el=>taskDialog(null,el.dataset.date), 'edit-task':el=>taskDialog(el.dataset.id),
 'cancel-task':el=>confirmDialog('¿Cancelar esta tarea?','Quedará marcada como cancelada y dejará de cubrir cualquier descanso asociado.',async()=>{state.tasks=state.tasks.map(t=>t.id===el.dataset.id?{...t,status:'cancelada'}:t);await persist();notice='Tarea cancelada.';render();},'Cancelar tarea'),
 'accept':async el=>{const updated=accept(state,el.dataset.id,state.actor);state.tasks=state.tasks.map(t=>t.id===updated.id?updated:t);await persist();notice=`${person(state.actor)} aceptó su responsabilidad.`;render();},
 'reject':el=>{const t=state.tasks.find(t=>t.id===el.dataset.id);if(t.assignee!==state.actor||t.status!=='propuesta')throw Error('Solo el responsable puede rechazar una propuesta pendiente.');confirmDialog('¿Rechazar esta propuesta?','La tarea quedará cancelada. El equipo podrá editarla y proponer otro responsable.',async()=>{t.status='cancelada';await persist();notice='Propuesta rechazada. El equipo puede ajustarla desde el plan.';render();},'Rechazar propuesta');},
 'complete':async el=>{const t=state.tasks.find(t=>t.id===el.dataset.id);if(t.assignee!==state.actor||t.status!=='aceptada')throw Error('Solo el responsable puede marcar su tarea aceptada como realizada.');t.status='realizada';await persist();notice='Tarea marcada como realizada.';render();},
 'new-rest':restDialog,
 'delete-rest':el=>confirmDialog('¿Quitar este descanso previsto?','Se quitará el bloque; las tareas de relevo se conservan para que el equipo pueda revisarlas.',async()=>{state.rests=state.rests.filter(r=>r.id!==el.dataset.id);await persist();render();},'Quitar bloque'),
 'prev-week':()=>{week=addDays(week,-7);render();}, 'next-week':()=>{week=addDays(week,7);render();}, 'current-week':()=>{week=monday(today(state.zone));render();},
 'copy-week':()=>{const copies=copyWeek(state,week);const target=week;const commit=async()=>{state.tasks=state.tasks.filter(t=>dateOf(t.start,state.zone)<target||dateOf(t.start,state.zone)>=addDays(target,7)).concat(copies);await persist();notice='Semana copiada. Todas las tareas son propuestas y necesitan una nueva confirmación. Los descansos se conservan; revisa su cobertura.';render();};if(weekTasks().length)confirmDialog('¿Reemplazar las tareas de esta semana?','Se sustituirán las tareas existentes por las de la semana anterior, sin copiar estados de aceptación o cumplimiento. Los bloques de descanso se conservan.',commit,'Reemplazar tareas');else return commit();},
 'adjust-next':()=>{week=addDays(week,7);go('semana');},
 'print':()=>window.print(), 'relay':relayDialog,
 'add-person':()=>personDialog(), 'edit-person':el=>personDialog(el.dataset.id),
 'wizard-back':()=>{readWizard(false);state.wizard.step--;persist();render();},
 'wizard-add-person':()=>{readWizard(false);draft().people.push({id:uid(),name:'',babyCare:false,availability:[{days:[1,2,3,4,5],start:'09:00',end:'13:00'}]});persist();render();},
 'wizard-remove-person':el=>{readWizard(false);draft().people.splice(Number(el.dataset.index),1);persist();render();},
 'wizard-save':()=>{readWizard(false);notice='Configuración guardada en este dispositivo. Usa «Configurar mi familia» para continuar.';go('hoy');}
};
if(real){
 actions.wizard=()=>dialog('Configurar familia',`${label('Nombre de la familia',`<input name="family" value="${esc(state.family)}" maxlength="60" required>`)}<p>Zona horaria: ${esc(state.zone)}. Declara tu disponibilidad desde Mi equipo y añade tareas y descansos desde Plan semanal.</p>`,async data=>{state.family=data.get('family').trim();await persist();closeDialog();render();});
 actions['add-person']=invitationsDialog;
 actions.invitations=invitationsDialog;
 actions.logout=async()=>{await real.api('/logout','POST',{});location.href='/familia.html';};
 actions.backup=()=>dialog('Copia del plan y borrador sin guardar',`<p>Esta copia no se importa automáticamente ni cambia la base de datos. Conserva el borrador si hubo un conflicto y aplica tus cambios después de cargar la versión actual.</p><label class="field"><span>Plan o último borrador sin guardar (JSON)</span><textarea readonly class="remote-draft">${esc(JSON.stringify(real.failedDraft||state,null,2))}</textarea></label>`,null,'<div class="dialog-buttons"><button type="button" class="btn secondary" data-action="close">Cerrar</button><button type="button" class="btn" data-action="reload-remote">Cargar versión actual</button></div>');
 actions['reload-remote']=async()=>{const value=await real.api('/families/'+real.id);state=value.plan;real.confirmed=structuredClone(state);real.revision=value.revision;real.error='';real.status='Versión actual cargada';closeDialog();notice='Versión actual cargada. El borrador anterior sigue disponible en Guardar copia / recuperar.';render();};
 actions.privacy=()=>dialog('Datos de tu familia','<p>Este espacio usa cuentas individuales y una base de datos en el servidor. Solo los miembros pueden consultar el plan. El creador gestiona los enlaces privados. No compartas un enlace con personas ajenas a tu equipo.</p><p>No incluyas datos clínicos. WhatsApp prepara un texto que decides enviar. La demo local funciona por separado. No se prometen horas de sueño.</p>',null,'<button type="button" class="btn" data-action="close">Cerrar</button>');
}
document.addEventListener('click',async e=>{if(e.target.closest('.skip-link')){e.preventDefault();$('#main-title')?.focus();return;}const el=e.target.closest('[data-action]');if(!el)return;try{if(real&&real.pending)throw Error('Espera a que termine el guardado.');await actions[el.dataset.action]?.(el);}catch(error){if($('#wizard-error'))$('#wizard-error').textContent=error.message;else if($('#dialog-error'))$('#dialog-error').textContent=error.message;else notify(error.message);}});
document.addEventListener('change',e=>{if(!real&&e.target.id==='actor'){state.actor=e.target.value;persist();notice=`Ahora estás simulando a ${person(state.actor)}. No es una cuenta real.`;render();}});
document.addEventListener('submit',async e=>{
 if(e.target.id==='wizard-form'){
 e.preventDefault();try{readWizard();if(state.wizard.step<4){state.wizard.step++;persist();render();$('#wizard-form h2')?.setAttribute('tabindex','-1');$('#wizard-form h2')?.focus();}else{const generated=generateFamily();confirmDialog('¿Crear este plan de demostración?','Se reemplazarán la familia y el plan locales actuales. Se guardarán solo en este dispositivo y todas las tareas empezarán como propuestas.',()=>{state=generated;week=draft()?.week||monday(dateOf(state.tasks[0].start,state.zone));persist();notice='Tu plan está creado. Cada adulto debe confirmar sus propuestas; revisa también las tareas sin cobertura.';go('semana');},'Crear plan local');}}catch(error){$('#wizard-error').textContent=error.message.startsWith('Invalid')?'Revisa la zona horaria y las fechas. Usa una zona como America/La_Paz.':error.message;}
 }
 if(e.target.id==='review-form'){e.preventDefault();state.reviews[week]=new FormData(e.target).get('answer');try{await persist();notify(real?'Revisión guardada en el servidor.':'Revisión guardada solo en este dispositivo.');}catch(error){notify(error.message);}}
});
render();

function remoteStatus(){
 const problem=!!real.error;
 return `<section id="storage-status" class="storage-status ${problem?'storage-unavailable':'storage-ready'}" role="${problem?'alert':'region'}" aria-label="Estado del almacenamiento"><div><strong>${esc(real.status)}</strong><p>${esc(real.error||'Los cambios confirmados se guardan en la base de datos. Las otras pantallas consultan actualizaciones cada 2 segundos; no se recarga un formulario abierto.')}</p></div><button class="btn secondary small" data-action="backup">Guardar copia / recuperar</button>${problem?'<button class="btn secondary small" data-action="reload-remote">Cargar versión actual</button>':''}</section>`;
}
function updateRemoteStatus(){const status=$('#storage-status');if(status)status.outerHTML=remoteStatus();const n=$('#notice');if(n){n.textContent=visibleNotice();n.hidden=!n.textContent;}}
async function invitationsDialog(){
 if(!real.owner)throw Error('Solo quien creó la familia puede crear o revocar invitaciones.');
 const {invitations}=await real.api('/families/'+real.id+'/invitations');
 dialog('Invitaciones privadas',`<p>Enlaces de un solo uso, válidos durante 48 horas. Quien reciba el enlace debe entrar con su propia cuenta. Envíalo por un canal privado.</p><button type="button" class="btn" id="new-invite">Crear enlace privado</button><div id="invite-result" role="status"></div><h3>Enlaces creados</h3>${invitations.map(i=>`<p>${esc(new Date(i.expires).toLocaleString('es'))} · ${i.used?'Utilizado':i.revoked?'Revocado':i.expires<=Date.now()?'Caducado':`Vigente <button type="button" class="text-button" data-revoke="${esc(i.id)}">Revocar enlace</button>`}</p>`).join('')||'<p>Aún no hay enlaces.</p>'}`,null,'<div class="dialog-buttons"><button type="button" class="btn secondary" data-action="close">Cerrar</button></div>');
 $('#new-invite').onclick=async e=>{e.target.disabled=true;try{const value=await real.api('/families/'+real.id+'/invitations','POST',{});$('#invite-result').innerHTML=`<label class="field"><span>Copia este enlace privado; solo se muestra ahora</span><input readonly value="${esc(value.url)}"></label><p>Caduca: ${esc(new Date(value.expires).toLocaleString('es'))}. Cierra y vuelve a abrir Invitaciones para revocarlo.</p>`;}catch(error){$('#invite-result').textContent=error.message;}finally{e.target.disabled=false;}};
 document.querySelectorAll('[data-revoke]').forEach(b=>b.onclick=async()=>{try{await real.api('/families/'+real.id+'/invitations/'+b.dataset.revoke,'DELETE',{});await invitationsDialog();}catch(error){$('#invite-result').textContent=error.message;}});
}
if(real){
 setInterval(async()=>{
  if(real.pending||real.error||document.querySelector('dialog[open]')||['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;
  try{const value=await real.api('/families/'+real.id);if(real.pending||document.querySelector('dialog[open]')||['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;
   if(value.revision>real.revision){state=value.plan;real.confirmed=structuredClone(state);real.revision=value.revision;real.status='Plan actualizado desde el servidor';notice='El plan se actualizó con los cambios del equipo.';render();}
  }catch(error){real.error=error.message;real.status='No se pudo actualizar el plan';updateRemoteStatus();}
 },2000);
 window.addEventListener('beforeunload',e=>{if(real.pending||real.failedDraft&&real.error){e.preventDefault();e.returnValue='';}});
}
