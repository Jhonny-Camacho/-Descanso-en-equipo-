import { Temporal } from '@js-temporal/polyfill';

export const STORAGE_KEY = 'descanso-en-equipo.demo.v1';
export const TYPES = ['Cambio de pañal', 'Preparar comida para los adultos', 'Lavar ropa', 'Hacer compras', 'Ordenar la casa', 'Preparar materiales de cuidado', 'Acompañar a la madre', 'Atender al bebé durante un relevo acordado', 'Coordinar una cita', 'Tarea personalizada'];
export const RELAY = TYPES[7];
export const DAYS = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
export const uid = () => globalThis.crypto.randomUUID();
export function today(zone) { return Temporal.Now.zonedDateTimeISO(zone).toPlainDate().toString(); }
export function addDays(date, n) { return Temporal.PlainDate.from(date).add({ days: n }).toString(); }
export function monday(date) { const d = Temporal.PlainDate.from(date); return d.subtract({ days: d.dayOfWeek - 1 }).toString(); }
export function at(local, zone) {
  return Temporal.PlainDateTime.from(local).toZonedDateTime(zone, { disambiguation: 'reject' }).toInstant().toString();
}
export function local(instant, zone) { return Temporal.Instant.from(instant).toZonedDateTimeISO(zone).toPlainDateTime().toString({ smallestUnit: 'minute' }); }
export function dateOf(instant, zone) { return local(instant, zone).slice(0, 10); }
const ms = (s) => Temporal.Instant.from(s).epochMilliseconds;
export function overlap(a, b) { return ms(a.start) < ms(b.end) && ms(b.start) < ms(a.end); }
export function validateInterval(start, end) {
  if (ms(end) <= ms(start)) throw new Error('La fecha y hora de fin deben ser posteriores al inicio. Para un turno nocturno, elige el día siguiente.');
}
export function available(person, task, zone) {
  if (!person || (task.type === RELAY && !person.babyCare)) return false;
  validateInterval(task.start, task.end);
  const first = addDays(dateOf(task.start, zone), -1);
  const last = dateOf(task.end, zone);
  for (let date = first; date <= last; date = addDays(date, 1)) {
    const day = Temporal.PlainDate.from(date).dayOfWeek;
    for (const w of person.availability) {
      if (!w.days.includes(day)) continue;
      try {
        const start = at(`${date}T${w.start}`, zone);
        const endDate = w.end <= w.start ? addDays(date, 1) : date;
        const end = at(`${endDate}T${w.end}`, zone);
        if (ms(task.start) >= ms(start) && ms(task.end) <= ms(end)) return true;
      } catch { /* A nonexistent or ambiguous daylight-saving window is not used. */ }
    }
  }
  return false;
}
export function conflict(tasks, task, acceptedOnly = true) {
  return tasks.find(t => t.id !== task.id && t.assignee && t.assignee === task.assignee && t.status !== 'cancelada' && (!acceptedOnly || t.status === 'aceptada') && overlap(t, task));
}
export function propose(tasks, people, zone) {
  const result = [];
  const load = Object.fromEntries(people.map(p => [p.id, 0]));
  for (const task of tasks) {
    validateInterval(task.start, task.end);
    const candidates = people.filter(p => p.id !== task.beneficiary && available(p, task, zone) && !conflict(result, { ...task, assignee: p.id }, false));
    candidates.sort((a, b) => load[a.id] - load[b.id] || a.id.localeCompare(b.id));
    const assignee = candidates[0]?.id || null;
    result.push({ ...task, assignee, status: 'propuesta' });
    if (assignee) load[assignee]++;
  }
  return result;
}
export function accept(state, id, actor) {
  const task = state.tasks.find(t => t.id === id);
  if (!task || task.status !== 'propuesta') throw new Error('Esta propuesta ya no está pendiente.');
  if (!actor || task.assignee !== actor) throw new Error('Solo la persona responsable puede confirmar su propuesta. Cambia la persona que estás simulando.');
  if (!available(state.people.find(p => p.id === actor), task, state.zone)) throw new Error('La tarea queda fuera de tu disponibilidad. Ajusta el horario antes de aceptar.');
  if (conflict(state.tasks, task)) throw new Error('Este horario se solapa con otro compromiso aceptado. Ajusta el plan antes de confirmar.');
  return { ...task, status: 'aceptada' };
}
export function editTask(state, task) {
  validateInterval(task.start, task.end);
  if (task.assignee && !available(state.people.find(p => p.id === task.assignee), task, state.zone)) throw new Error('El responsable no está disponible durante todo ese intervalo o no puede asumir un relevo del bebé. Elige otro horario o deja la tarea sin responsable.');
  if (task.assignee && conflict(state.tasks, task)) throw new Error('Este horario se solapa con otro compromiso aceptado de la misma persona. Ajusta el horario o el responsable antes de guardar.');
  const old = state.tasks.find(t => t.id === task.id);
  const changed = !old || ['start', 'end', 'assignee', 'type', 'description'].some(k => old[k] !== task[k]);
  return { ...task, status: changed ? 'propuesta' : old.status };
}
export function coverage(rest, state) {
  const matches = state.tasks.filter(t => t.type === RELAY && t.assignee && t.assignee !== rest.person && t.status !== 'cancelada' && ms(t.start) <= ms(rest.start) && ms(t.end) >= ms(rest.end));
  const accepted = matches.find(t => t.status === 'aceptada');
  return accepted ? { label: 'Con cobertura aceptada', task: accepted } : { label: 'Sin cobertura confirmada', task: matches[0] };
}
export function affected(state, person) {
  return state.tasks.filter(t => t.assignee === person.id && t.status === 'aceptada' && !available(person, t, state.zone));
}
export function shiftTask(task, days, zone) {
  const shift = value => {
    const l = local(value, zone);
    return at(addDays(l.slice(0, 10), days) + l.slice(10), zone);
  };
  return { ...task, id: uid(), start: shift(task.start), end: shift(task.end), status: 'propuesta' };
}
export function copyWeek(state, target) {
  const previous = addDays(target, -7);
  const source = state.tasks.filter(t => dateOf(t.start, state.zone) >= previous && dateOf(t.start, state.zone) < target && t.status !== 'cancelada');
  if (!source.length) throw new Error('No hay tareas en la semana anterior para copiar. Puedes añadir tareas a esta semana.');
  return source.map(t => {
    const copy = shiftTask(t, 7, state.zone);
    if (copy.assignee && !available(state.people.find(p => p.id === copy.assignee), copy, state.zone)) copy.assignee = null;
    return copy;
  });
}
export function relayMessage({ task, start, end, note }, state) {
  const a = task?.start || start; const b = task?.end || end;
  validateInterval(a, b);
  const fmt = v => new Intl.DateTimeFormat('es', { timeZone: state.zone, dateStyle: 'medium', timeStyle: 'short' }).format(new Date(v));
  return `¿Alguien puede ayudar con ${task?.type || 'un relevo acordado'}?\nDesde ${fmt(a)} hasta ${fmt(b)} (${state.zone}).${note ? `\n${note}` : ''}\nPor favor, confirmemos quién puede asumirlo. Este mensaje no confirma la cobertura.`;
}
export function seed() {
  const zone = 'America/La_Paz';
  const current = today(zone); const week = monday(current);
  const people = [
    { id: 'ana', name: 'Ana', babyCare: true, availability: [{ days: [1,2,3,4,5,6,7], start: '08:00', end: '18:00' }] },
    { id: 'leo', name: 'Leo', babyCare: true, availability: [{ days: [1,2,3,4,5], start: '18:00', end: '23:00' }, { days: [6,7], start: '08:00', end: '23:00' }] },
    { id: 'elena', name: 'Elena', babyCare: false, availability: [{ days: [1,3,5,6], start: '10:00', end: '15:00' }] }
  ];
  const tasks = [];
  for (let d = 0; d < 7; d++) {
    const date = addDays(week, d);
    for (const [h, end, type, who, status] of [
      ['12:00','13:00', TYPES[1], [0,2,4,5].includes(d) ? 'elena' : 'ana', 'propuesta'],
      ['19:00','20:00', RELAY, 'leo', d === 0 ? 'aceptada' : 'propuesta'],
      ['23:00','23:30', TYPES[0], null, 'propuesta']
    ]) tasks.push({ id: uid(), start: at(`${date}T${h}`, zone), end: at(`${date}T${end}`, zone), type, description: '', assignee: who, status });
  }
  const rests = Array.from({ length: 7 }, (_, d) => ({ id: uid(), person: 'ana', start: at(`${addDays(week,d)}T19:00`,zone), end: at(`${addDays(week,d)}T20:00`,zone) }));
  const previous = tasks.map((t, i) => ({ ...shiftTask(t, -7, zone), status: i % 3 === 0 ? 'realizada' : 'propuesta' }));
  return { version: 1, family: 'Familia de Ana', zone, people, tasks: [...previous, ...tasks], rests, actor: 'leo', wizard: { step: 1, draft: null }, reviews: {}, custom: false };
}
