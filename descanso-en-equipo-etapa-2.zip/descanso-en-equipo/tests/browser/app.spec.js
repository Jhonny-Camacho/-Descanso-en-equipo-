import { test, expect } from '@playwright/test';
const key='descanso-en-equipo.demo.v1';
const read=page=>page.evaluate(k=>JSON.parse(localStorage.getItem(k)),key);
async function open(page,route='hoy') {await page.goto('/#'+route);await expect(page.locator('#main-title')).toBeVisible();}
async function bootstrap(page) {await open(page);await page.locator('#actor').selectOption('ana');}

// Each test has its own isolated browser storage. No real accounts, messages or family data.
test('Presentación, navegación, ayuda y recorrido de teclado',async({page})=>{
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await open(page,'inicio');await expect(page.getByRole('heading',{name:/Organicen los cuidados/})).toBeVisible();
 await expect(page.getByText('Sin registro. Con datos ficticios.')).toBeVisible();
 await page.keyboard.press('Tab');await expect(page.getByRole('link',{name:'Saltar al contenido'})).toBeFocused();await page.keyboard.press('Enter');await expect(page.locator('#main-title')).toBeFocused();await expect(page).toHaveURL(/#inicio$/);
 await page.getByText('¿Los cambios se ven en otros teléfonos?').click();await expect(page.getByText('En esta demostración, no.',{exact:false})).toBeVisible();
 await page.getByRole('link',{name:'Probar demostración'}).click();await expect(page.getByRole('heading',{name:'Hoy, nos cuidamos en equipo.'})).toBeVisible();
 await page.getByRole('link',{name:'Mi equipo',exact:true}).click();await expect(page.locator('.person-card')).toHaveCount(3);
 await page.getByRole('link',{name:'Revisión semanal',exact:true}).click();await page.locator('[name=answer]').selectOption('si');await page.getByRole('button',{name:'Guardar revisión'}).click();await expect(page.getByRole('status')).toContainText('Revisión guardada');
 await expect(page.getByText('Reparto injusto',{exact:true})).toHaveCount(0);expect(errors).toEqual([]);
});

test('Crear familia, tres cuidadores, guardar y continuar, propuestas válidas y sin cobertura',async({page})=>{
 await open(page,'inicio');await page.getByRole('button',{name:'Crear mi plan',exact:true}).click();
 await page.locator('[name=family]').fill('Equipo Colibrí');await page.locator('[name=zone]').fill('America/La_Paz');
 await page.getByRole('button',{name:'Continuar',exact:true}).click();
 await page.locator('[name=person-name-0]').fill('Mara');await page.locator('[name=person-start-0]').fill('08:00');await page.locator('[name=person-end-0]').fill('13:00');
 await page.getByRole('button',{name:'Añadir otro adulto'}).click();await page.locator('[name=person-name-1]').fill('Nico');await page.locator('[name=person-baby-1]').check();await page.locator('[name=person-start-1]').fill('18:00');await page.locator('[name=person-end-1]').fill('22:00');
 await page.getByRole('button',{name:'Añadir otro adulto'}).click();await page.locator('[name=person-name-2]').fill('Luz');await page.locator('[name=person-start-2]').fill('10:00');await page.locator('[name=person-end-2]').fill('14:00');
 await page.getByRole('button',{name:'Guardar y continuar después'}).click();await expect(page.getByRole('status')).toContainText('Configuración guardada');await page.reload();
 // The resume action is available on the landing page on all screen sizes.
 await page.goto('/#inicio');await page.getByRole('button',{name:'Crear mi plan',exact:true}).click();await expect(page.locator('[name=person-name-2]')).toHaveValue('Luz');
 await page.getByRole('button',{name:'Continuar',exact:true}).click();await page.getByRole('button',{name:'Continuar',exact:true}).click();
 await page.locator('[name=restPerson]').selectOption({label:'Mara'});await page.getByRole('button',{name:'Generar mi plan'}).click();await page.getByRole('button',{name:'Crear plan local'}).click();
 await expect(page.locator('.week-grid')).toBeVisible();const s=await read(page);expect(s.family).toBe('Equipo Colibrí');expect(s.people).toHaveLength(3);expect(new Set(s.people.map(p=>p.availability[0].start)).size).toBe(3);expect(s.tasks.every(t=>t.status==='propuesta')).toBe(true);expect(s.tasks.some(t=>!t.assignee)).toBe(true);
 expect(s.tasks.filter(t=>t.type.includes('relevo')).every(t=>t.assignee!==s.people[0].id)).toBe(true);
 await page.reload();await expect(page.locator('.topbar-title')).toHaveText('Equipo Colibrí');
});

test('Aceptar, realizar y rechazar con la persona responsable simulada',async({page})=>{
 await bootstrap(page);await page.getByRole('link',{name:'Plan semanal',exact:true}).click();
 const card=page.locator('.task').filter({has:page.getByRole('button',{name:'Aceptar',exact:true})}).first();await card.getByRole('button',{name:'Aceptar',exact:true}).click();await expect(page.getByRole('status')).toContainText('Ana aceptó');
 const accepted=page.locator('.task').filter({has:page.getByRole('button',{name:'Marcar realizada'})}).first();await accepted.getByRole('button',{name:'Marcar realizada'}).click();await expect(page.getByRole('status')).toContainText('realizada');
 const rejected=page.locator('.task').filter({has:page.getByRole('button',{name:'Rechazar',exact:true})}).first();await rejected.getByRole('button',{name:'Rechazar',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'Rechazar propuesta'}).click();await expect(page.getByRole('status')).toContainText('Propuesta rechazada');
 await page.reload();const s=await read(page);expect(s.tasks.some(t=>t.status==='realizada'&&t.assignee==='ana')).toBe(true);expect(s.tasks.some(t=>t.status==='cancelada'&&t.assignee==='ana')).toBe(true);
});

test('Crear y aceptar turno nocturno de 23:00 a 01:00 del día siguiente',async({page})=>{
 await bootstrap(page);await page.goto('/#equipo');await page.locator('[data-action=edit-person][data-id=ana]').click();
 await page.locator('[name=start-0]').fill('22:00');await page.locator('[name=end-0]').fill('02:00');await page.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();
 await page.goto('/#semana');const date=await page.locator('[data-action=new-task][data-date]').first().getAttribute('data-date');const nextDay=new Date(date+'T12:00:00Z');nextDay.setUTCDate(nextDay.getUTCDate()+1);const endDate=nextDay.toISOString().slice(0,10);await page.getByRole('button',{name:'Añadir tarea',exact:true}).click();
 await page.locator('[name=start]').fill(date+'T23:00');await page.locator('[name=end]').fill(endDate+'T01:00');await page.locator('[name=assignee]').selectOption('ana');await page.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();
 const card=page.locator('.task').filter({hasText:'23:00 –'}).filter({hasText:'Preparar comida'});await expect(card).toContainText('01:00');await card.getByRole('button',{name:'Aceptar',exact:true}).click();await expect(card.locator('.pill.aceptada')).toBeVisible();await page.reload();await expect(card.locator('.pill.aceptada')).toBeVisible();
});

test('Editar tarea aceptada exige confirmación y bloquea fuera de disponibilidad',async({page})=>{
 await bootstrap(page);await page.goto('/#semana');await page.locator('#actor').selectOption('leo');
 const accepted=page.locator('.task').filter({has:page.locator('.pill.aceptada')}).first();await accepted.getByRole('button',{name:/Editar/}).click();
 await page.locator('input[name=description]').fill('Traer los materiales antes del relevo');await page.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();await expect(page.getByRole('status')).toContainText('propuesta');
 const s=await read(page);expect(s.tasks.find(t=>t.description==='Traer los materiales antes del relevo').status).toBe('propuesta');
 await page.getByRole('button',{name:'Añadir tarea',exact:true}).click();await page.locator('[name=start]').fill('2026-10-26T04:00');await page.locator('[name=end]').fill('2026-10-26T05:00');await page.locator('[name=assignee]').selectOption('leo');await page.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();await expect(page.locator('#dialog-error')).toContainText('no está disponible');
});

test('Cambio de disponibilidad advierte sobre compromisos y conserva responsable',async({page})=>{
 await bootstrap(page);await page.goto('/#equipo');await page.locator('[data-action=edit-person][data-id=leo]').click();
 await page.locator('[name=start-0]').fill('21:00');await page.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();await expect(page.getByRole('heading',{name:'Hay compromisos que revisar'})).toBeVisible();
 await page.getByRole('button',{name:'Guardar y señalar'}).click();await page.goto('/#semana');await expect(page.getByText('Disponibilidad cambió · revisar').first()).toBeVisible();
 expect((await read(page)).tasks.find(t=>t.status==='aceptada').assignee).toBe('leo');
});

test('Copiar semana exige confirmar reemplazo y reinicia estados',async({page})=>{
 await bootstrap(page);await page.goto('/#semana');const before=await read(page);
 await page.getByRole('button',{name:'Copiar semana anterior'}).click();await expect(page.getByRole('heading',{name:'¿Reemplazar las tareas de esta semana?'})).toBeVisible();await page.getByRole('button',{name:'Volver',exact:true}).click();expect((await read(page)).tasks).toEqual(before.tasks);
 await page.getByRole('button',{name:'Copiar semana anterior'}).click();await page.getByRole('button',{name:'Reemplazar tareas',exact:true}).click();await expect(page.getByRole('status')).toContainText('Todas las tareas son propuestas');await expect(page.locator('.week-grid .pill.aceptada')).toHaveCount(0);await expect(page.locator('.week-grid .pill.realizada')).toHaveCount(0);
});

test('Preparar y copiar un relevo no lo acepta ni dice que fue enviado',async({page,context})=>{
 await context.grantPermissions(['clipboard-read','clipboard-write']);await bootstrap(page);const before=(await read(page)).tasks;
 await page.getByRole('button',{name:'Necesito un relevo'}).click();await page.locator('[name=note]').fill('¿Puedes acompañarme?');await page.getByRole('button',{name:'Preparar mensaje'}).click();
 await expect(page.getByRole('heading',{name:'Mensaje listo para revisar'})).toBeVisible();await expect(page.locator('#relay-text')).toContainText('America/La_Paz');
 const url=await page.locator('#whatsapp').getAttribute('href');expect(url).toMatch(/^https:\/\/wa.me\/\?text=/);expect(decodeURIComponent(url)).not.toContain('http://');
 await page.getByRole('button',{name:'Copiar mensaje'}).click();await expect(page.locator('#copy-result')).toContainText('Tú decides');expect(await page.evaluate(()=>navigator.clipboard.readText())).toContain('¿Puedes acompañarme?');expect((await read(page)).tasks).toEqual(before);
});

test('Impresión en A4 con resumen y PDF real',async({page})=>{
 await bootstrap(page);await page.goto('/#semana');await page.emulateMedia({media:'print'});await expect(page.locator('.print-summary')).toBeVisible();await expect(page.locator('.sidebar')).toBeHidden();await expect(page.locator('.print-summary tbody tr')).toHaveCount(21);
 await page.pdf({path:'test-results/resumen-semanal.pdf',format:'A4',printBackground:true});
});

test('Reinicio confirmado borra solo la clave de demostración',async({page})=>{
 await bootstrap(page);await page.evaluate(()=>localStorage.setItem('otra-aplicacion','conservar'));
 await page.getByRole('button',{name:'Reiniciar demostración',exact:true}).click();await page.getByRole('button',{name:'Volver',exact:true}).click();expect((await read(page)).actor).toBe('ana');
 await page.getByRole('button',{name:'Reiniciar demostración',exact:true}).click();await page.getByRole('button',{name:'Reiniciar datos de demo'}).click();expect((await read(page)).actor).toBe('leo');expect(await page.evaluate(()=>localStorage.getItem('otra-aplicacion'))).toBe('conservar');
});

test('Pantalla móvil: sin desbordamientos, navegación y formulario por teclado',async({page})=>{
 await page.setViewportSize({width:390,height:844});await open(page,'inicio');await expect(page.getByRole('button',{name:'Crear mi plan',exact:true})).toBeVisible();
 expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
 await page.getByRole('link',{name:'Probar demostración'}).click();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
 await page.getByRole('link',{name:'Plan semanal',exact:true}).click();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
 await page.getByRole('button',{name:'Añadir tarea',exact:true}).click();const first=page.locator('[name=type]');await first.focus();await page.keyboard.press('Tab');await expect(page.locator('input[name=description]')).toBeFocused();await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).toHaveCount(0);
 await page.goto('/#inicio');await page.getByRole('button',{name:'Crear mi plan',exact:true}).click();expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
});

test('Solapamiento bloqueado en pantalla; consecutivas aceptadas y cambios reconfirmados',async({page})=>{
 await bootstrap(page);await page.goto('/#semana');
 const date=await page.locator('[data-action=new-task][data-date]').first().getAttribute('data-date');
 async function create(start,end,note){
  await page.getByRole('button',{name:'Añadir tarea',exact:true}).click();
  await page.locator('[name=start]').fill(`${date}T${start}`);await page.locator('[name=end]').fill(`${date}T${end}`);await page.locator('[name=assignee]').selectOption('ana');await page.locator('input[name=description]').fill(note);await page.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();
  return page.locator('.task').filter({hasText:note});
 }
 const first=await create('09:00','10:00','Turno primero');
 const second=await create('09:30','10:30','Turno segundo');
 await first.getByRole('button',{name:'Aceptar',exact:true}).click();await expect(first.locator('.pill.aceptada')).toBeVisible();await second.getByRole('button',{name:'Aceptar',exact:true}).click();await expect(page.getByRole('status')).toContainText('se solapa');await expect(second.locator('.pill.propuesta')).toBeVisible();
 await second.getByRole('button',{name:/Editar/}).click();await page.locator('[name=start]').fill(`${date}T10:00`);await page.locator('[name=end]').fill(`${date}T11:00`);await page.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();await second.getByRole('button',{name:'Aceptar',exact:true}).click();await expect(second.locator('.pill.aceptada')).toBeVisible();
 await second.getByRole('button',{name:/Editar/}).click();await page.locator('input[name=description]').fill('Turno segundo ajustado');await page.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();await expect(second.locator('.pill.propuesta')).toBeVisible();await second.getByRole('button',{name:'Aceptar',exact:true}).click();await expect(second.locator('.pill.aceptada')).toBeVisible();
});

test('Descanso pasa de sin cobertura confirmada a cobertura aceptada',async({page})=>{
 await bootstrap(page);await page.goto('/#semana');await page.locator('#actor').selectOption('leo');
 const column=page.locator('.day-column').nth(1);
 await expect(column.locator('.rest-card')).toContainText('Sin cobertura confirmada');
 await column.locator('.task').filter({hasText:'Atender al bebé durante un relevo acordado'}).getByRole('button',{name:'Aceptar',exact:true}).click();
 await expect(column.locator('.rest-card')).toContainText('Con cobertura aceptada');
});

test('Accesibilidad automática WCAG AA en las seis pantallas y diálogo',async({page})=>{
 const {default:AxeBuilder}=await import('@axe-core/playwright');
 for(const route of ['inicio','hoy','semana','equipo','revision','configurar']) {
  await open(page,route);
  const {violations}=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa']).analyze();
  expect(violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({html:n.html,summary:n.failureSummary}))})),route).toEqual([]);
 }
 await page.goto('/#semana');await page.getByRole('button',{name:'Añadir tarea',exact:true}).click();
 const {violations}=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa']).analyze();expect(violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({html:n.html,summary:n.failureSummary}))}))).toEqual([]);
});

test('HTML empaquetado carga sin recursos externos y conserva cambios bajo HTTP',async({page})=>{
 const {readFile}=await import('node:fs/promises');const {resolve}=await import('node:path');const html=await readFile(resolve('dist/descanso-demo.html'),'utf8');
 // This managed Chromium forbids file: navigation. Serve the exact file through a mocked HTTP document; permit no other resources.
 await page.route('**/descanso-demo.html',route=>route.fulfill({contentType:'text/html; charset=utf-8',body:html}));
 const errors=[],external=[];page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(r.url().startsWith('http'))external.push(r.url());});
 await page.goto('/descanso-demo.html');
 await expect(page.locator('#main-title')).toContainText('Organicen los cuidados');await page.getByRole('link',{name:'Probar demostración'}).click();await expect(page.locator('#main-title')).toContainText('Hoy');
 await page.locator('#actor').selectOption('elena');await page.reload();await expect(page.locator('#actor')).toHaveValue('elena');
 await page.getByRole('link',{name:'Plan semanal',exact:true}).click();await expect(page.locator('.day-column')).toHaveCount(7);expect(errors).toEqual([]);expect(external.every(url=>new URL(url).pathname==='/descanso-demo.html')).toBe(true);
});
