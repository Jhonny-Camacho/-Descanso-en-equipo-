import { test, expect } from '@playwright/test';
const key = 'descanso-en-equipo.demo.v1';

async function openTuesday(page, sandbox = false, packaged = false) {
  await page.clock.install({ time: new Date('2026-10-23T16:00:00Z') });
  if (packaged) {
    const { readFile } = await import('node:fs/promises');
    const html = await readFile('dist/descanso-demo.html', 'utf8');
    await page.route('**/packaged-demo', route => route.fulfill({ contentType: 'text/html', body: html }));
  }
  const url = packaged ? '/packaged-demo#semana' : '/#semana';
  if (sandbox) {
    await page.route('**/sandbox-reproduction', route => route.fulfill({
      contentType: 'text/html',
      body: `<iframe title="Demostración" sandbox="allow-scripts allow-same-origin" src="${url}" style="width:100%;height:95vh;border:0"></iframe>`
    }));
    await page.goto('/sandbox-reproduction');
  } else await page.goto(url);
  const app = sandbox ? page.frameLocator('iframe') : page;
  const day = app.locator('.day-column').nth(1);
  await expect(day.locator('.day-heading')).toContainText('Martes 20');
  const task = day.locator('.task').filter({ hasText: 'Atender al bebé durante un relevo acordado' });
  await task.getByRole('button', { name: 'Aceptar', exact: true }).click();
  await expect(task.locator('.pill.aceptada')).toBeVisible();
  await task.getByRole('button', { name: /Editar/ }).click();
  await app.locator('[name=start]').fill('2026-10-20T19:30');
  await app.locator('[name=end]').fill('2026-10-20T20:30');
  return { app, task };
}

for (const [name, sandbox, packaged] of [['normal', false, false], ['vista incrustada sin envío nativo', true, false], ['HTML descargable en vista incrustada', true, true]]) {
  test(`Leo martes 20/10: guardar 19:30–20:30 · ${name}`, async ({ page }) => {
    const { app, task } = await openTuesday(page, sandbox, packaged);
    await app.getByRole('dialog').getByRole('button', { name: 'Guardar', exact: true }).click();
    await expect(app.getByRole('dialog')).toHaveCount(0);
    await expect(task).toContainText('19:30 – 20:30');
    await expect(task).toContainText('Por confirmar');
    await page.reload();
    await expect(app.locator('.day-column').nth(1)).toContainText('19:30 – 20:30');
    const s = await page.evaluate(k => JSON.parse(localStorage.getItem(k)), key);
    const t = s.tasks.find(t => t.start === '2026-10-20T23:30:00Z');
    expect(t).toMatchObject({ end: '2026-10-21T00:30:00Z', assignee: 'leo', status: 'propuesta' });
  });
}

test('Fuera de disponibilidad: error visible, valores conservados y reintento válido', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const { app, task } = await openTuesday(page, true);
  await app.locator('[name=start]').fill('2026-10-20T22:30');
  await app.locator('[name=end]').fill('2026-10-20T23:30');
  await app.locator('input[name=description]').fill('Esperar a que llegue Elena');
  await app.getByRole('dialog').getByRole('button', { name: 'Guardar', exact: true }).click();
  const error = app.locator('#dialog-error');
  await expect(error).toContainText('no está disponible durante todo ese intervalo');
  await expect(error).toBeInViewport();
  await expect(error).toBeFocused();
  await expect(app.locator('[name=start]')).toHaveValue('2026-10-20T22:30');
  await expect(app.locator('[name=end]')).toHaveValue('2026-10-20T23:30');
  await expect(app.locator('input[name=description]')).toHaveValue('Esperar a que llegue Elena');
  const before = await page.evaluate(k => JSON.parse(localStorage.getItem(k)), key);
  expect(before.tasks.find(t => t.start === '2026-10-20T23:00:00Z' && t.assignee === 'leo').status).toBe('aceptada');
  expect(before.tasks.some(t => t.description === 'Esperar a que llegue Elena')).toBe(false);
  await app.locator('[name=start]').fill('2026-10-20T19:30');
  await app.locator('[name=end]').fill('2026-10-20T20:30');
  await app.getByRole('dialog').getByRole('button', { name: 'Guardar', exact: true }).click();
  await expect(app.getByRole('dialog')).toHaveCount(0);
  await expect(task).toContainText('Esperar a que llegue Elena');
  await expect(task).toContainText('Por confirmar');
});

test('Cruce al editar: no modifica la tarea aceptada, conserva datos y admite límite consecutivo', async ({ page }) => {
  const { app, task } = await openTuesday(page);
  await app.getByRole('button', { name: 'Volver', exact: true }).click();
  await app.getByRole('button', { name: 'Añadir tarea', exact: true }).click();
  await app.locator('[name=start]').fill('2026-10-20T20:30');
  await app.locator('[name=end]').fill('2026-10-20T21:30');
  await app.locator('[name=assignee]').selectOption('leo');
  await app.locator('input[name=description]').fill('Compromiso vecino');
  await app.getByRole('dialog').getByRole('button', { name: 'Guardar', exact: true }).click();
  const neighbor = app.locator('.task').filter({ hasText: 'Compromiso vecino' });
  await neighbor.getByRole('button', { name: 'Aceptar', exact: true }).click();
  await task.getByRole('button', { name: /Editar/ }).click();
  await app.locator('[name=start]').fill('2026-10-20T19:30');
  await app.locator('[name=end]').fill('2026-10-20T20:45');
  await app.getByRole('dialog').getByRole('button', { name: 'Guardar', exact: true }).click();
  await expect(app.locator('#dialog-error')).toContainText('se solapa con otro compromiso aceptado');
  await expect(app.locator('[name=start]')).toHaveValue('2026-10-20T19:30');
  await expect(app.locator('[name=end]')).toHaveValue('2026-10-20T20:45');
  const unchanged = await page.evaluate(k => JSON.parse(localStorage.getItem(k)), key);
  expect(unchanged.tasks.find(t => t.start === '2026-10-20T23:00:00Z' && t.assignee === 'leo')).toMatchObject({ end: '2026-10-21T00:00:00Z', status: 'aceptada' });
  await app.locator('[name=end]').fill('2026-10-20T20:30');
  await app.getByRole('dialog').getByRole('button', { name: 'Guardar', exact: true }).click();
  await expect(app.getByRole('dialog')).toHaveCount(0);
  await expect(task).toContainText('19:30 – 20:30');
  await expect(task).toContainText('Por confirmar');
  await page.reload();
  await expect(task).toContainText('19:30 – 20:30');
  await expect(neighbor.locator('.pill.aceptada')).toBeVisible();
});

test('Validaciones de fechas vacías y fin anterior siguen activas en vista incrustada', async ({ page }) => {
  const { app } = await openTuesday(page, true);
  await app.locator('[name=start]').fill('');
  await app.getByRole('dialog').getByRole('button', { name: 'Guardar', exact: true }).click();
  await expect(app.locator('#dialog-error')).toContainText('Inicio · fecha y hora:');
  await expect(app.locator('#dialog-error')).toBeVisible();
  await expect(app.locator('[name=end]')).toHaveValue('2026-10-20T20:30');
  await app.locator('[name=start]').fill('2026-10-20T21:00');
  await app.getByRole('dialog').getByRole('button', { name: 'Guardar', exact: true }).click();
  await expect(app.locator('#dialog-error')).toContainText('fin deben ser posteriores al inicio');
  await expect(app.locator('[name=start]')).toHaveValue('2026-10-20T21:00');
  await expect(app.locator('[name=end]')).toHaveValue('2026-10-20T20:30');
});

test('Guardar con Enter también funciona en vista incrustada', async ({ page }) => {
  const { app, task } = await openTuesday(page, true);
  await app.locator('input[name=description]').focus();
  await page.keyboard.press('Enter');
  await expect(app.getByRole('dialog')).toHaveCount(0);
  await expect(task).toContainText('19:30 – 20:30');
  await expect(task).toContainText('Por confirmar');
});
