import { test, expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';

async function embedded(page, storageAllowed) {
  await page.clock.install({ time: new Date('2026-10-23T16:00:00Z') });
  const html = await readFile('dist/descanso-demo.html', 'utf8');
  await page.route('**/persistence-demo', route => route.fulfill({ contentType: 'text/html', body: html }));
  await page.route('**/persistence-host', route => route.fulfill({ contentType: 'text/html', body: `<iframe title="Demo" sandbox="allow-scripts${storageAllowed?' allow-same-origin':''}" src="/persistence-demo#semana" style="width:100%;height:95vh;border:0"></iframe>` }));
  await page.goto('/persistence-host');
  return page.frameLocator('iframe');
}
async function completeJourney(app) {
  const day=app.locator('.day-column').nth(1);
  const task=day.locator('.task').filter({hasText:'Atender al bebé durante un relevo acordado'});
  await task.getByRole('button',{name:'Aceptar',exact:true}).click();
  await task.getByRole('button',{name:/Editar/}).click();
  await app.locator('[name=start]').fill('2026-10-20T19:30');
  await app.locator('[name=end]').fill('2026-10-20T20:30');
  await app.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();
  await task.getByRole('button',{name:'Aceptar',exact:true}).click();
  await day.getByRole('button',{name:'Eliminar descanso previsto'}).click();
  await app.getByRole('button',{name:'Quitar bloque',exact:true}).click();
  await app.getByRole('link',{name:'Hoy',exact:true}).click();
  await app.locator('[data-action=new-rest]').click();
  await app.locator('[name=person]').selectOption('ana');
  await app.locator('[name=start]').fill('2026-10-20T19:30');
  await app.locator('[name=end]').fill('2026-10-20T20:30');
  await app.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();
  await app.getByRole('link',{name:'Plan semanal',exact:true}).click();
  await checkJourney(app);
}
async function checkJourney(app) {
  const day=app.locator('.day-column').nth(1);
  const task=day.locator('.task').filter({hasText:'Atender al bebé durante un relevo acordado'});
  await expect(task).toContainText('19:30 – 20:30');
  await expect(task.locator('.pill.aceptada')).toBeVisible();
  await expect(day.locator('.rest-card')).toHaveCount(1);
  await expect(day.locator('.rest-card')).toContainText('19:30 – 20:30');
  await expect(day.locator('.rest-card')).toContainText('Con cobertura aceptada · Leo');
}
test('Recorrido completo incrustado: almacenamiento permitido y datos idénticos tras recarga',async({page})=>{
  const app=await embedded(page,true);
  await completeJourney(app);
  const frame=page.frames().find(f=>f.url().includes('/persistence-demo'));
  const before=await frame.evaluate(()=>localStorage.getItem('descanso-en-equipo.demo.v1'));
  expect(before).not.toBeNull();
  await page.reload();
  await checkJourney(app);
  const after=await page.frames().find(f=>f.url().includes('/persistence-demo')).evaluate(()=>localStorage.getItem('descanso-en-equipo.demo.v1'));
  expect(after).toBe(before);
});

async function restore(app,copy){
  await app.locator('[data-action=backup]').first().click();
  await app.locator('[name=backup]').fill(copy);
  await app.getByRole('button',{name:'Revisar recuperación',exact:true}).click();
  await app.getByRole('button',{name:'Reemplazar con esta copia',exact:true}).click();
}

test('Recorrido completo incrustado: bloqueo real, aviso sin falso éxito y recuperación de copia',async({page})=>{
  const app=await embedded(page,false);
  const access=await page.frames().find(f=>f.url().includes('/persistence-demo')).evaluate(()=>{try{localStorage.getItem('descanso-en-equipo.demo.v1');return 'allowed';}catch(e){return e.name;}});
  expect(access).toBe('SecurityError');
  await expect(app.locator('#storage-status')).toContainText('se perderán al recargar');
  await completeJourney(app);
  await expect(app.locator('#notice')).toContainText('No se ha guardado para recargar');
  await expect(app.locator('#notice')).not.toContainText('guardada');
  await app.locator('[data-action=backup]').first().click();
  const copy=await app.locator('#backup-export').inputValue();
  expect(JSON.parse(copy).plan.tasks.some(t=>t.status==='aceptada'&&t.start==='2026-10-20T23:30:00Z')).toBe(true);
  await app.getByRole('button',{name:'Copiar copia del plan'}).click();
  await expect(app.locator('#backup-copy-result')).toContainText('Texto seleccionado');
  const selected=await app.locator('#backup-export').evaluate(el=>el.selectionEnd-el.selectionStart);
  expect(selected).toBe(copy.length);
  await page.reload();
  await expect(app.locator('#storage-status')).toContainText('se perderán al recargar');
  await restore(app,copy);
  await checkJourney(app);
  await expect(app.locator('#notice')).toContainText('No se ha guardado para recargar');
});

test('Fallo de escritura no se presenta como guardado; recuperación funciona en otra vista con almacenamiento',async({page})=>{
  await page.addInitScript(()=>{
    const original=Storage.prototype.setItem;
    Storage.prototype.setItem=function(k,v){if(k==='descanso-en-equipo.demo.v1')throw new DOMException('Full','QuotaExceededError');return original.call(this,k,v);};
  });
  const app=await embedded(page,true);
  await completeJourney(app);
  await expect(app.locator('#storage-status')).toHaveAttribute('data-mode','memory');
  await expect(app.locator('#notice')).toContainText('No se ha guardado para recargar');
  await app.locator('[data-action=backup]').first().click();
  const copy=await app.locator('#backup-export').inputValue();
  // Use a new browser context, without the failing storage override.
  const context=await page.context().browser().newContext();
  const other=await context.newPage();const recovered=await embedded(other,true);
  await restore(recovered,copy);await checkJourney(recovered);
  await other.reload();await checkJourney(recovered);
  await context.close();
});

test('Datos corruptos protegidos e importación inválida no reemplaza el plan',async({page})=>{
  await page.addInitScript(()=>{if(!sessionStorage.getItem('fixture-set')){localStorage.setItem('descanso-en-equipo.demo.v1','{broken');sessionStorage.setItem('fixture-set','yes');}});
  const app=await embedded(page,true);
  await expect(app.locator('#storage-status')).toHaveAttribute('data-mode','recovery');
  await app.locator('[data-action=backup]').first().click();
  await expect(app.getByRole('textbox',{name:'Texto anterior sin modificar (conservar antes de reemplazar)'})).toHaveValue('{broken');
  await app.locator('[name=backup]').fill('{"version":1}');
  await app.getByRole('button',{name:'Revisar recuperación'}).click();
  await expect(app.locator('#dialog-error')).toContainText('No se ha reemplazado el plan actual');
  await app.getByRole('button',{name:'Cerrar',exact:true}).click();
  await completeJourney(app);
  const raw=await page.frames().find(f=>f.url().includes('/persistence-demo')).evaluate(()=>localStorage.getItem('descanso-en-equipo.demo.v1'));
  expect(raw).toBe('{broken');
});
