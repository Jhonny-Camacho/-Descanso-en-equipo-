import test from 'node:test';
import assert from 'node:assert/strict';
import { createDemoStorage, backupText, parseBackup } from '../src/storage.js';
import { seed, STORAGE_KEY, at, RELAY } from '../src/planner.js';
const memory = () => {const map=new Map();return {getItem:k=>map.get(k)??null,setItem:(k,v)=>map.set(k,v),removeItem:k=>map.delete(k)};};
test('La clave v1 se conserva y un plan válido no se sustituye al arrancar',()=>{
 assert.equal(STORAGE_KEY,'descanso-en-equipo.demo.v1');const store=memory(),s=seed();s.family='Mi plan existente';store.setItem(STORAGE_KEY,JSON.stringify(s));
 const storage=createDemoStorage(()=>store);assert.deepEqual(storage.load(),s);assert.equal(store.getItem(STORAGE_KEY),JSON.stringify(s));
});
test('Escritura y lectura verificadas; estado completo conservado',()=>{
 const store=memory(),storage=createDemoStorage(()=>store);assert.equal(storage.load(),null);
 const s=seed();assert.equal(storage.save(s),true);const next=createDemoStorage(()=>store);assert.deepEqual(next.load(),s);assert.equal(next.mode,'ready');
});
test('Storage bloqueado por SecurityError se detecta antes del primer cambio',()=>{
 const storage=createDemoStorage(()=>{throw new DOMException('Blocked','SecurityError');});assert.equal(storage.load(),null);assert.equal(storage.mode,'memory');assert.equal(storage.errorName,'SecurityError');assert.equal(storage.save(seed()),false);
});
test('QuotaExceeded y escrituras no retenidas nunca devuelven éxito',()=>{
 const store=memory();const storage=createDemoStorage(()=>store);storage.load();
 store.setItem=()=>{throw new DOMException('Full','QuotaExceededError');};assert.equal(storage.save(seed()),false);assert.equal(storage.mode,'memory');
 const silent=createDemoStorage(()=>({getItem:()=>null,setItem:()=>{},removeItem:()=>{}}));silent.load();assert.equal(silent.mode,'memory');assert.equal(silent.save(seed()),false);
});
test('Datos corruptos no son sobrescritos al cambiar la demo; reemplazo solo explícito',()=>{
 const store=memory();store.setItem(STORAGE_KEY,'{invalid');const storage=createDemoStorage(()=>store);assert.equal(storage.load(),null);assert.equal(storage.mode,'recovery');assert.equal(storage.unreadableRaw,'{invalid');assert.equal(storage.save(seed()),false);assert.equal(store.getItem(STORAGE_KEY),'{invalid');assert.equal(storage.save(seed(),{replace:true}),true);
});
test('Copia recuperable conserva horario, aceptación y descanso; no repropone al importar',()=>{
 const s=seed();const start=at('2026-10-20T19:30',s.zone),end=at('2026-10-20T20:30',s.zone);
 s.tasks=[{id:'relay',start,end,type:RELAY,assignee:'leo',description:'Relevo',status:'aceptada'}];s.rests=[{id:'rest',person:'ana',start,end}];const restored=parseBackup(backupText(s));assert.deepEqual(restored,s);assert.equal(restored.tasks[0].status,'aceptada');
});
test('Copias inválidas, referencias desconocidas o cruces aceptados se rechazan',()=>{
 assert.throws(()=>parseBackup('no JSON'),/copia no es/);assert.throws(()=>parseBackup('{"version":1}'),/copia no es/);
 const s=seed();s.rests[0].person='desconocido';assert.throws(()=>parseBackup(JSON.stringify(s)),/copia no es/);
 const unsafe=seed();unsafe.tasks[0].id='"><img src=x>';assert.throws(()=>parseBackup(JSON.stringify(unsafe)),/copia no es/);
 const other=seed();const t=other.tasks.find(t=>t.status==='aceptada');other.tasks.push({...t,id:'duplicate-conflict'});assert.throws(()=>parseBackup(JSON.stringify(other)),/copia no es/);
});
