import { test } from 'node:test';
import assert from 'node:assert/strict';
import { win32, posix } from 'node:path';
import { createApp, isInsideDirectory } from '../server/server.js';

test('Windows: reproduce el rechazo anterior y permite HTML/recursos dentro de la raíz',()=>{
 const base=win32.resolve('E:\\PROMPT PARA NEGOCIOS IDEAS\\descanso-en-equipo\\dist-real');
 for(const file of ['familia.html','real-assets/app.js','real-assets/style.css']){
  const resolved=win32.resolve(base,file);
  assert.equal(resolved.startsWith(base+'/'),false,'La comprobación anterior falla en Windows');
  assert.equal(isInsideDirectory(base,resolved,win32),true);
 }
 assert.equal(isInsideDirectory(base,win32.resolve(base,'..archivo-valido.js'),win32),true);
 assert.equal(isInsideDirectory(base,win32.resolve(base,'..','package.json'),win32),false);
 assert.equal(isInsideDirectory(base,base,win32),false);
 assert.equal(isInsideDirectory(base,'C:\\Windows\\win.ini',win32),false);
 assert.equal(isInsideDirectory(base,base+'-privado\\secret.txt',win32),false);
 const unc='\\\\equipo\\carpeta\\dist-real';
 assert.equal(isInsideDirectory(unc,win32.join(unc,'familia.html'),win32),true);
 assert.equal(isInsideDirectory(unc,'\\\\otro\\carpeta\\archivo',win32),false);
});
test('Linux: mantiene la lectura interna y el bloqueo de rutas ajenas',()=>{
 const base='/app/dist-real';
 assert.equal(isInsideDirectory(base,'/app/dist-real/familia.html',posix),true);
 assert.equal(isInsideDirectory(base,'/app/dist-real/real-assets/app.js',posix),true);
 for(const file of [base,'/app/package.json','/app/dist-real-privado/secret','/etc/passwd'])assert.equal(isInsideDirectory(base,file,posix),false);
});
test('HTTP: sirve la página familiar y sus recursos; no expone archivos del proyecto',async t=>{
 const app=createApp({dbPath:':memory:'});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
 t.after(()=>app.close());
 const base='http://127.0.0.1:'+app.server.address().port;
 const response=await fetch(base+'/familia.html');assert.equal(response.status,200);assert.match(response.headers.get('content-type'),/text\/html/);
 const html=await response.text();
 const resources=[...html.matchAll(/(?:src|href)="(\/real-assets\/[^\"]+)"/g)].map(m=>m[1]);
 assert.ok(resources.length>=2);
 for(const resource of resources)assert.equal((await fetch(base+resource)).status,200,resource);
 for(const file of ['/package.json','/server/server.js','/%2e%2e%2fpackage.json','/%2e%2e%5cpackage.json'])assert.equal((await fetch(base+file)).status,404,file);
 assert.equal((await fetch(base+'/api/session')).status,401);
});
