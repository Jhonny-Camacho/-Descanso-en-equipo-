import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createApp } from '../server/server.js';
import { at, RELAY, TYPES } from '../src/planner.js';
const origin='http://localhost:3001';
async function fixture(t,{disk=false}={}){
 let clock=Date.now();const directory=mkdtempSync(join(tmpdir(),'descanso-test-'));
 const app=createApp({dbPath:disk?join(directory,'plan.sqlite'):':memory:',origin,now:()=>clock});
 await new Promise(r=>app.server.listen(0,'127.0.0.1',r));
 const base='http://127.0.0.1:'+app.server.address().port;
 const client=()=>{let cookie='';return async(path,method='GET',data,customOrigin=origin)=>{
  const r=await fetch(base+'/api'+path,{method,headers:{...(cookie?{Cookie:cookie}:{}),...(method!=='GET'?{'Content-Type':'application/json',Origin:customOrigin}:{})},body:data?JSON.stringify(data):undefined});
  if(r.headers.get('set-cookie'))cookie=r.headers.get('set-cookie').split(';')[0];
  return {status:r.status,data:await r.json(),headers:r.headers};
 };};
 const a=client(),b=client(),c=client();
 const register=async(api,name)=>{const r=await api('/register','POST',{name,email:name+'@example.test',password:'prueba-unica-123456'});assert.equal(r.status,200);return r.data.user;};
 const ana=await register(a,'Ana'),leo=await register(b,'Leo'),other=await register(c,'Otra');
 const created=await a('/families','POST',{family:'Familia A',zone:'America/La_Paz'});assert.equal(created.status,201);const id=created.data.id;
 const get=async(api=a)=>{const r=await api('/families/'+id);assert.equal(r.status,200);return r.data;};
 const put=(snapshot,api=a)=>api('/families/'+id,'PUT',{revision:snapshot.revision,plan:snapshot.plan});
 const invite=async()=>{const r=await a('/families/'+id+'/invitations','POST',{});assert.equal(r.status,201);return {...r.data,token:r.data.url.split('=')[1]};};
 const joinFamily=async()=>{const inv=await invite();assert.equal((await b('/invitations/accept','POST',{token:inv.token})).status,200);};
 const availability=async()=>{await joinFamily();for(const [api,u] of [[a,ana],[b,leo]]){const s=await get(api);const p=s.plan.people.find(p=>p.id===u.id);p.babyCare=true;p.availability=[{days:[1,2,3,4,5,6,7],start:'18:00',end:'23:00'}];assert.equal((await put(s,api)).status,200);}};
 const task=(id='task1',start='19:00',end='20:00')=>({id,type:RELAY,description:'',assignee:leo.id,start:at('2026-10-20T'+start,'America/La_Paz'),end:at('2026-10-20T'+end,'America/La_Paz'),status:'propuesta'});
 t.after(async()=>{await app.close();rmSync(directory,{recursive:true,force:true});});
 return {app,a,b,c,ana,leo,other,id,get,put,invite,joinFamily,availability,task,client,advance:ms=>clock+=ms,directory};
}
test('cuentas reales, contraseña derivada, sesión HttpOnly y cierre de sesión',async t=>{
 const f=await fixture(t);const user=f.app.db.prepare('SELECT * FROM users WHERE id=?').get(f.ana.id);assert.notEqual(user.password,'prueba-unica-123456');assert.equal(user.password.length,128);
 assert.equal((await f.client()('/families')).status,401);
 const login=await f.a('/login','POST',{email:'ana@example.test',password:'prueba-unica-123456'});assert.match(login.headers.get('set-cookie'),/HttpOnly; SameSite=Strict/);
 assert.equal((await f.a('/logout','POST',{})).status,200);assert.equal((await f.a('/session')).status,401);
 assert.equal((await f.a('/login','POST',{email:'ana@example.test',password:'incorrecta-123456'})).status,401);
});
test('sesión caducada no permite leer el plan',async t=>{const f=await fixture(t);f.advance(8*86400000);assert.equal((await f.a('/families/'+f.id)).status,401);});
test('SQL y API aíslan dos familias y rechazan escrituras directas sin membresía',async t=>{
 const f=await fixture(t);const otherFamily=await f.c('/families','POST',{family:'Familia B',zone:'UTC'});
 assert.equal((await f.a('/families/'+otherFamily.data.id)).status,404);assert.equal((await f.c('/families/'+f.id)).status,404);
 const s=await f.get();assert.equal((await f.put(s,f.c)).status,404);assert.equal((await f.c('/families/'+f.id+'/invitations','POST',{})).status,404);
 const list=await f.c('/families');assert.deepEqual(list.data.families.map(x=>x.id),[otherFamily.data.id]);
 assert.equal(f.app.db.prepare('SELECT count(*) AS n FROM members WHERE family_id=? AND user_id=?').get(f.id,f.other.id).n,0);
});
test('invitación privada permite incorporarse una sola vez; token guardado como hash',async t=>{
 const f=await fixture(t);const inv=await f.invite();const stored=f.app.db.prepare('SELECT * FROM invites WHERE id=?').get(inv.id);assert.notEqual(stored.token,inv.token);
 assert.equal((await f.b('/invitations/accept','POST',{token:inv.token})).status,200);assert.equal((await f.c('/invitations/accept','POST',{token:inv.token})).status,410);
 const s=await f.get(f.b);assert.equal(s.plan.actor,f.leo.id);assert.equal(s.plan.tasks.length,0);assert.equal(s.plan.people.length,2);
 assert.equal((await f.b('/families/'+f.id+'/invitations','POST',{})).status,404);
});
test('revocación y caducidad se comprueban en el servidor',async t=>{
 const f=await fixture(t);const inv=await f.invite();assert.equal((await f.a('/families/'+f.id+'/invitations/'+inv.id,'DELETE',{})).status,200);
 assert.equal((await f.b('/invitations/accept','POST',{token:inv.token})).status,410);
 const inv2=await f.invite();f.advance(2*86400000+1);assert.equal((await f.b('/invitations/accept','POST',{token:inv2.token})).status,410);
});
test('solo el responsable acepta incluso falsificando actor; validación en servidor',async t=>{
 const f=await fixture(t);await f.availability();let s=await f.get();s.plan.tasks.push(f.task());assert.equal((await f.put(s)).status,200);
 s=await f.get();s.plan.actor=f.leo.id;s.plan.tasks[0].status='aceptada';assert.equal((await f.put(s)).status,403);
 s=await f.get(f.b);s.plan.tasks[0].status='aceptada';assert.equal((await f.put(s,f.b)).status,200);
 s=await f.get();s.plan.tasks[0].status='realizada';assert.equal((await f.put(s)).status,403);
});
test('API bloquea propuestas fuera de disponibilidad, cruces y aceptación forjada',async t=>{
 const f=await fixture(t);await f.availability();let s=await f.get();s.plan.tasks.push(f.task('fuera','04:00','05:00'));assert.equal((await f.put(s)).status,422);
 s=await f.get();s.plan.tasks.push({...f.task(),status:'aceptada'});assert.equal((await f.put(s)).status,403);
 s=await f.get();s.plan.tasks.push(f.task(),f.task('task2','19:30','20:30'));assert.equal((await f.put(s)).status,200);
 s=await f.get(f.b);s.plan.tasks[0].status='aceptada';assert.equal((await f.put(s,f.b)).status,200);
 s=await f.get(f.b);s.plan.tasks[1].status='aceptada';const crossing=await f.put(s,f.b);assert.equal(crossing.status,422);assert.match(crossing.data.error,/cruce/);
 s=await f.get();s.plan.tasks[1].start=at('2026-10-20T19:45',s.plan.zone);assert.equal((await f.put(s)).status,422);
});
test('cambiar horario exige reconfirmación y permanece con descanso tras reabrir SQLite',async t=>{
 const f=await fixture(t,{disk:true});await f.availability();let s=await f.get();s.plan.tasks.push(f.task());await f.put(s);
 s=await f.get(f.b);s.plan.tasks[0].status='aceptada';await f.put(s,f.b);
 s=await f.get();s.plan.tasks[0].start=at('2026-10-20T19:30',s.plan.zone);s.plan.tasks[0].end=at('2026-10-20T20:30',s.plan.zone);assert.equal((await f.put(s)).status,403);
 s.plan.tasks[0].status='propuesta';assert.equal((await f.put(s)).status,200);
 s=await f.get(f.b);s.plan.tasks[0].status='aceptada';assert.equal((await f.put(s,f.b)).status,200);
 s=await f.get();s.plan.rests.push({id:'rest1',person:f.ana.id,start:s.plan.tasks[0].start,end:s.plan.tasks[0].end});assert.equal((await f.put(s)).status,200);
 const {DatabaseSync}=await import('node:sqlite');const disk=new DatabaseSync(join(f.directory,'plan.sqlite'));const saved=JSON.parse(disk.prepare('SELECT plan FROM families WHERE id=?').get(f.id).plan);disk.close();assert.equal(saved.tasks[0].status,'aceptada');assert.equal(saved.rests[0].start,saved.tasks[0].start);
 const reopened=createApp({dbPath:join(f.directory,'plan.sqlite'),origin});await new Promise(r=>reopened.server.listen(0,'127.0.0.1',r));await reopened.close();
 assert.deepEqual((await f.get()).plan.rests,saved.rests);
});
test('dos escrituras simultáneas: una confirma y otra obtiene 409 sin sobrescribir',async t=>{
 const f=await fixture(t);await f.joinFamily();const a=await f.get(),b=await f.get(f.b);a.plan.family='Cambio Ana';b.plan.family='Cambio Leo';
 const result=await Promise.all([f.put(a),f.put(b,f.b)]);assert.deepEqual(result.map(x=>x.status).sort(),[200,409]);const final=await f.get();assert.equal(final.revision,a.revision+1);
});
test('nadie puede fabricar miembros ni cambiar disponibilidad ajena',async t=>{
 const f=await fixture(t);await f.joinFamily();let s=await f.get();s.plan.people[1].babyCare=true;assert.equal((await f.put(s)).status,403);
 s=await f.get();s.plan.people.push({id:f.other.id,name:'intruso',babyCare:true,availability:[]});assert.equal((await f.put(s)).status,403);
});
test('orígenes externos bloqueados aunque tengan cookie',async t=>{const f=await fixture(t);assert.equal((await f.a('/families','POST',{family:'Ataque',zone:'UTC'},'https://otro.example')).status,403);});
test('SQLite no expuesto por HTTP y errores no muestran contraseña',async t=>{const f=await fixture(t);const base='http://127.0.0.1:'+f.app.server.address().port;assert.equal((await fetch(base+'/data/descanso.sqlite')).status,404);const r=await f.a('/login','POST',{email:'ana@example.test',password:'incorrecta-123456'});assert.equal(r.data.error,'Correo o contraseña incorrectos.');});
test('reinicio completo del servidor conserva cuenta, sesión y plan en disco',async t=>{
 const directory=mkdtempSync(join(tmpdir(),'descanso-restart-')),dbPath=join(directory,'plan.sqlite');let app;
 const start=async()=>{app=createApp({dbPath,origin});await new Promise(r=>app.server.listen(0,'127.0.0.1',r));return 'http://127.0.0.1:'+app.server.address().port;};
 t.after(async()=>{await app.close();rmSync(directory,{recursive:true,force:true});});
 let base=await start();const auth=await fetch(base+'/api/register',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify({name:'Persistente',email:'persistente@example.test',password:'contraseña-prueba-12345'})});assert.equal(auth.status,200);const cookie=auth.headers.get('set-cookie').split(';')[0];
 const created=await fetch(base+'/api/families',{method:'POST',headers:{Origin:origin,Cookie:cookie,'Content-Type':'application/json'},body:JSON.stringify({family:'Plan persistente',zone:'UTC'})});const {id}=await created.json();assert.equal(created.status,201);
 await app.close();base=await start();
 const result=await fetch(base+'/api/families/'+id,{headers:{Cookie:cookie}});assert.equal(result.status,200);assert.equal((await result.json()).plan.family,'Plan persistente');
});
