import { test,expect } from '@playwright/test';
const errors=[];
async function register(page,name){
 page.on('pageerror',e=>errors.push(e.message));
 await page.goto('/familia.html');await page.getByRole('button',{name:'Crear una cuenta',exact:true}).click();
 await page.getByLabel('Tu nombre o alias').fill(name);await page.getByLabel('Correo electrónico').fill(`${name.toLowerCase()}-${crypto.randomUUID()}@example.test`);await page.getByLabel('Contraseña (mínimo 12 caracteres)').fill('solo-para-prueba-123456');await page.getByRole('button',{name:'Crear cuenta',exact:true}).click();await expect(page.getByRole('heading',{name:'Tu espacio familiar'})).toBeVisible();
}
async function createFamily(page){await page.getByLabel('Nombre de la familia').fill('Equipo de prueba');await page.getByRole('button',{name:'Crear familia y configurar plan'}).click();await expect(page.locator('.week-grid')).toBeVisible();}
async function request(page,path,method='GET',body){return page.evaluate(async({path,method,body})=>{const r=await fetch('/api'+path,{method,headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined});return {status:r.status,body:await r.json()};},{path,method,body});}
const familyId=page=>new URL(page.url()).searchParams.get('familia');
async function invite(page){await page.getByRole('button',{name:'Invitaciones',exact:true}).click();await page.getByRole('button',{name:'Crear enlace privado'}).click();const input=page.getByLabel('Copia este enlace privado; solo se muestra ahora');await expect(input).toBeVisible();const url=await input.inputValue();await page.getByRole('dialog').getByRole('button',{name:'Cerrar',exact:true}).click();return url;}
async function ownAvailability(page,name){await page.getByRole('link',{name:'Mi equipo',exact:true}).click();await page.locator('.person-card').filter({has:page.getByRole('heading',{name,exact:true})}).getByRole('button',{name:'Editar disponibilidad'}).click();await page.getByLabel('Puede asumir relevos del bebé',{exact:true}).check();await page.locator('[name="start-0"]').fill('18:00');await page.locator('[name="end-0"]').fill('23:00');for(let i=1;i<=7;i++)await page.locator(`[name="days-0"][value="${i}"]`).check();await page.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await page.getByRole('link',{name:'Plan semanal',exact:true}).click();}
async function addTask(page,name='Relevo compartido',start='19:00',end='20:00'){
 await page.getByRole('button',{name:'Añadir tarea',exact:true}).click();await page.locator('[name=type]').selectOption('Atender al bebé durante un relevo acordado');await page.locator('[name=description]').fill(name);await page.locator('[name=start]').fill('2026-10-20T'+start);await page.locator('[name=end]').fill('2026-10-20T'+end);await page.locator('[name=assignee]').selectOption({label:'Leo'});await page.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);
}
async function previousWeek(page){while(!await page.locator('[data-action=new-task][data-date="2026-10-20"]').count())await page.getByRole('button',{name:'Semana anterior',exact:true}).click();}
test('dos cuentas y navegadores comparten plan real, aceptación propia, edición, descanso y recarga',async({browser})=>{
 errors.length=0;const ca=await browser.newContext(),cb=await browser.newContext();const a=await ca.newPage(),b=await cb.newPage();
 try{
 await register(a,'Ana');await createFamily(a);const id=familyId(a);await ownAvailability(a,'Ana');const link=await invite(a);
 // Sign up through the actual invitation, without a pre-existing account.
 await b.goto(link);await b.getByRole('button',{name:'Crear una cuenta',exact:true}).click();await b.getByLabel('Tu nombre o alias').fill('Leo');await b.getByLabel('Correo electrónico').fill(`leo-${crypto.randomUUID()}@example.test`);await b.getByLabel('Contraseña (mínimo 12 caracteres)').fill('solo-para-prueba-123456');await b.getByRole('button',{name:'Crear cuenta',exact:true}).click();await expect(b.getByRole('heading',{name:'Aceptar invitación'})).toBeVisible();await b.getByRole('button',{name:'Aceptar invitación privada'}).click();await expect(b.locator('.week-grid')).toBeVisible();await ownAvailability(b,'Leo');
 await expect.poll(async()=>a.evaluate(()=>window.realPlan.confirmed.people.find(p=>p.name==='Leo')?.availability[0]?.start)).toBe('18:00');await previousWeek(a);await previousWeek(b);
 await addTask(a);const ta=a.locator('.task').filter({hasText:'Relevo compartido'}),tb=b.locator('.task').filter({hasText:'Relevo compartido'});
 await expect(ta.getByRole('button',{name:'Aceptar',exact:true})).toHaveCount(0);await expect(tb).toBeVisible({timeout:7000});await tb.getByRole('button',{name:'Aceptar',exact:true}).click();await expect(ta.locator('.pill.aceptada')).toBeVisible({timeout:7000});
 await ta.getByRole('button',{name:/Editar/}).click();await a.locator('[name=start]').fill('2026-10-20T19:30');await a.locator('[name=end]').fill('2026-10-20T20:30');await a.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();await expect(tb.locator('.pill.propuesta')).toBeVisible({timeout:7000});await tb.getByRole('button',{name:'Aceptar',exact:true}).click();await expect(ta.locator('.pill.aceptada')).toBeVisible({timeout:7000});
 await a.getByRole('button',{name:'Añadir descanso previsto',exact:true}).click();await a.locator('[name=person]').selectOption({label:'Ana'});await a.locator('[name=start]').fill('2026-10-20T19:30');await a.locator('[name=end]').fill('2026-10-20T20:30');await a.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();await expect(a.getByRole('dialog')).toHaveCount(0);await expect(b.locator('.rest-card')).toContainText('Con cobertura aceptada',{timeout:7000});
 await a.reload();await b.reload();await expect(a.locator('.week-grid')).toBeVisible();await expect(b.locator('.week-grid')).toBeVisible();await previousWeek(a);await previousWeek(b);await expect(a.locator('.task-time').filter({hasText:'19:30'})).toContainText('20:30');await expect(b.locator('.task .pill.aceptada')).toHaveCount(1);await expect(a.locator('.rest-card')).toContainText('Con cobertura aceptada');
 const stored=await request(a,'/families/'+id);expect(stored.body.plan.tasks[0].status).toBe('aceptada');expect(stored.body.plan.rests).toHaveLength(1);
 expect(await a.evaluate(()=>localStorage.getItem('descanso-en-equipo.demo.v1'))).toBeNull();expect(await b.locator('#actor').count()).toBe(0);
 await a.getByRole('link',{name:'Revisión semanal',exact:true}).click();await a.locator('[name=answer]').selectOption('si');await a.getByRole('button',{name:'Guardar revisión'}).click();await expect(a.locator('#notice')).toContainText('Revisión guardada en el servidor');
 await a.getByRole('link',{name:'Plan semanal',exact:true}).click();await previousWeek(a);await a.getByRole('link',{name:'Hoy',exact:true}).click();await a.getByRole('button',{name:'Necesito un relevo'}).click();await a.getByRole('button',{name:'Preparar mensaje'}).click();expect(await a.locator('#whatsapp').getAttribute('href')).toMatch(/^https:\/\/wa.me/);await a.getByRole('dialog').getByRole('button',{name:'Cerrar',exact:true}).click();
 await a.getByRole('link',{name:'Plan semanal',exact:true}).click();await previousWeek(a);await a.emulateMedia({media:'print'});await expect(a.locator('.print-summary')).toBeVisible();await a.pdf({path:'test-results-real/familia-real.pdf',format:'A4'});
 expect(errors).toEqual([]);
 }finally{await ca.close();await cb.close();}
});
test('conflicto conserva campos, muestra motivo y borrador; fallo de red no anuncia éxito',async({browser})=>{
 const ca=await browser.newContext(),cb=await browser.newContext();const a=await ca.newPage(),b=await cb.newPage();
 try{
 await register(a,'Ana');await createFamily(a);const link=await invite(a);await register(b,'Leo');await b.goto(link);await b.getByRole('button',{name:'Aceptar invitación privada'}).click();await expect(b.locator('.week-grid')).toBeVisible();await ownAvailability(b,'Leo');await expect.poll(async()=>a.evaluate(()=>window.realPlan.confirmed.people.find(p=>p.name==='Leo')?.availability[0]?.start)).toBe('18:00');
 await a.getByRole('button',{name:'Añadir tarea',exact:true}).click();await a.locator('[name=description]').fill('Mi borrador conservado');await a.locator('[name=start]').fill('2026-10-20T19:00');await a.locator('[name=end]').fill('2026-10-20T20:00');await a.locator('[name=assignee]').selectOption({label:'Leo'});
 const id=familyId(b);const s=await request(b,'/families/'+id);s.body.plan.family='Cambio desde otro dispositivo';expect((await request(b,'/families/'+id,'PUT',s.body)).status).toBe(200);
 await a.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();await expect(a.locator('#dialog-error')).toContainText('Otra persona cambió');await expect(a.locator('[name=description]')).toHaveValue('Mi borrador conservado');await expect(a.locator('#storage-status')).toContainText('Cambio sin guardar');await a.getByRole('button',{name:'Cerrar ventana'}).click();await a.locator('#storage-status [data-action=backup]').click();await expect(a.locator('.remote-draft')).toContainText('Mi borrador conservado');await a.getByRole('button',{name:'Cargar versión actual',exact:true}).last().click();await expect(a.locator('.topbar-title')).toHaveText('Cambio desde otro dispositivo');
 await a.route('**/api/families/'+id,r=>r.request().method()==='PUT'?r.abort():r.continue());
 await a.getByRole('button',{name:'Añadir tarea',exact:true}).click();await a.locator('[name=description]').fill('Sin conexión');await a.locator('[name=assignee]').selectOption('');await a.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();await expect(a.locator('#dialog-error')).toContainText('No se ha confirmado el guardado');await expect(a.locator('[name=description]')).toHaveValue('Sin conexión');
 }finally{await ca.close();await cb.close();}
});
test('una lectura antigua que llega tarde no revierte un guardado confirmado',async({page})=>{
 await register(page,'Ana');await createFamily(page);const id=familyId(page);
 let release,captured;const gate=new Promise(r=>release=r),ready=new Promise(r=>captured=r);let intercepted=false;
 await page.route('**/api/families/'+id,async route=>{
  if(route.request().method()==='GET'&&!intercepted){intercepted=true;const response=await route.fetch();captured();await gate;await route.fulfill({response});}else await route.continue();
 });
 await ready;
 await page.locator('[data-action=wizard]').first().click();await page.getByRole('dialog').getByLabel('Nombre de la familia').fill('Guardado más reciente');await page.getByRole('dialog').getByRole('button',{name:'Guardar',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);const revision=await page.evaluate(()=>window.realPlan.revision);
 const arrived=page.waitForResponse(r=>r.url().endsWith('/api/families/'+id)&&r.request().method()==='GET');release();await arrived;
 await page.evaluate(()=>new Promise(r=>setTimeout(r,200)));
 expect(await page.evaluate(()=>window.realPlan.revision)).toBe(revision);await expect(page.locator('.topbar-title')).toHaveText('Guardado más reciente');
});
