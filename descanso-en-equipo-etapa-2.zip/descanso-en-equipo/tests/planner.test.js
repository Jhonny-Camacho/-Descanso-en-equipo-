import test from 'node:test';
import assert from 'node:assert/strict';
import { at, local, available, overlap, accept, editTask, propose, coverage, affected, copyWeek, relayMessage, seed, TYPES, RELAY } from '../src/planner.js';
const zone='America/La_Paz';
const stamp=s=>at(s,zone);
const person=(id='a',start='09:00',end='17:00',days=[1,2,3,4,5,6,7])=>({id,name:id,babyCare:true,availability:[{days,start,end}]});
const task=(start='2026-10-26T10:00',end='2026-10-26T11:00',more={})=>({id:crypto.randomUUID(),type:TYPES[1],start:stamp(start),end:stamp(end),assignee:'a',status:'propuesta',description:'',...more});
const setup=(tasks,people=[person()])=>({zone,tasks,people});

test('Tres adultos y disponibilidades diferentes en la familia ficticia',()=>{
 const s=seed();assert.equal(s.people.length,3);assert.equal(new Set(s.people.map(p=>JSON.stringify(p.availability))).size,3);assert.ok(s.tasks.every(t=>!t.assignee||available(s.people.find(p=>p.id===t.assignee),t,s.zone)));
});
test('Generación determinista: propuestas válidas y sin cobertura',()=>{
 const tasks=[task(),task('2026-10-26T23:00','2026-10-27T00:00')];
 const a=propose(tasks,[person()],zone);assert.deepEqual(a,propose(tasks,[person()],zone));assert.equal(a[0].assignee,'a');assert.equal(a[1].assignee,null);assert.ok(a.every(t=>t.status==='propuesta'));
});
test('Propuestas simultáneas no se asignan a la misma persona',()=>{
 const result=propose([task(),task()],[person('a'),person('b')],zone);assert.notEqual(result[0].assignee,result[1].assignee);
});
test('Solo el responsable puede aceptar una propuesta',()=>{
 const t=task();assert.throws(()=>accept(setup([t]),t.id,'b'),/Solo la persona/);assert.equal(accept(setup([t]),t.id,'a').status,'aceptada');
});
test('Se bloquea solapamiento de compromisos aceptados',()=>{
 const a=task(undefined,undefined,{status:'aceptada'}),b=task('2026-10-26T10:30','2026-10-26T11:30');assert.ok(overlap(a,b));assert.throws(()=>accept(setup([a,b]),b.id,'a'),/solapa/);
});
test('Se permiten tareas consecutivas y responsables diferentes',()=>{
 const a=task(undefined,undefined,{status:'aceptada'}),b=task('2026-10-26T11:00','2026-10-26T12:00');assert.equal(overlap(a,b),false);assert.equal(accept(setup([a,b]),b.id,'a').status,'aceptada');
 const c=task(undefined,undefined,{assignee:'b'});assert.equal(accept(setup([a,c],[person('a'),person('b')]),c.id,'b').status,'aceptada');
});
test('Turno de 23:00 a 01:00 del día siguiente y disponibilidad del día previo',()=>{
 const p=person('a','22:00','02:00',[1]); const t=task('2026-10-26T23:00','2026-10-27T01:00');assert.ok(available(p,t,zone));assert.ok(available(p,task('2026-10-27T00:00','2026-10-27T01:00'),zone));assert.equal(available(p,task('2026-10-27T23:00','2026-10-28T01:00'),zone),false);
});
test('Intervalos negativos o nulos se rechazan',()=>{
 assert.throws(()=>editTask(setup([]),task('2026-10-26T11:00','2026-10-26T10:00')),/posteriores/);assert.throws(()=>available(person(),task('2026-10-26T11:00','2026-10-26T11:00'),zone),/posteriores/);
});
test('Cambiar horario, responsable, tipo o descripción exige nueva confirmación',()=>{
 const t=task(undefined,undefined,{status:'aceptada'}),s=setup([t],[person('a'),person('b')]);
 for(const change of [{end:stamp('2026-10-26T11:30')},{assignee:'b'},{type:TYPES[2]},{description:'Otro acuerdo'}])assert.equal(editTask(s,{...t,...change}).status,'propuesta');
 assert.equal(editTask(s,{...t}).status,'aceptada');assert.throws(()=>editTask(s,{...t,start:stamp('2026-10-26T06:00')}),/no está disponible/);
});
test('Cambio de disponibilidad detecta compromisos sin reasignarlos',()=>{
 const t=task(undefined,undefined,{status:'aceptada'}),s=setup([t]);const changed=person('a','12:00','16:00');assert.equal(affected(s,changed).length,1);assert.equal(s.tasks[0].assignee,'a');assert.equal(s.tasks[0].status,'aceptada');assert.throws(()=>accept(setup([task()],[changed]),'missing','a'));
});
test('Descanso distingue propuesta de cobertura aceptada y de ayuda doméstica',()=>{
 const t=task(undefined,undefined,{type:RELAY});const r={...t,person:'b'};const s=setup([t]);assert.equal(coverage(r,s).label,'Sin cobertura confirmada');t.status='aceptada';assert.equal(coverage(r,s).label,'Con cobertura aceptada');t.type=TYPES[1];assert.equal(coverage(r,s).label,'Sin cobertura confirmada');t.type=RELAY;r.person='a';assert.equal(coverage(r,s).label,'Sin cobertura confirmada');
});
test('Un relevo no se asigna al beneficiario ni a apoyo solo doméstico',()=>{
 const t=task(undefined,undefined,{type:RELAY,beneficiary:'a'}),p=person('b');p.babyCare=false;assert.equal(propose([t],[person('a'),p],zone)[0].assignee,null);
});
test('Copiar semana conserva fechas nocturnas y elimina estados de cumplimiento',()=>{
 const t=task('2026-10-26T23:00','2026-10-27T01:00',{status:'realizada'}),s=setup([t],[person('a','22:00','02:00')]);const [copy]=copyWeek(s,'2026-11-02');assert.equal(copy.status,'propuesta');assert.notEqual(copy.id,t.id);assert.equal(local(copy.start,zone),'2026-11-02T23:00');assert.equal(local(copy.end,zone),'2026-11-03T01:00');
 s.people[0].availability=[];assert.equal(copyWeek(s,'2026-11-02')[0].assignee,null);assert.throws(()=>copyWeek(s,'2026-11-16'),/No hay tareas/);
});
test('Zona horaria: instantes reales, cambio de fecha y horario de verano',()=>{
 assert.equal(stamp('2026-10-26T23:00'),'2026-10-27T03:00:00Z');assert.throws(()=>at('2026-03-29T02:30','Europe/Madrid'));assert.throws(()=>at('2026-10-25T02:30','Europe/Madrid'));assert.equal(local(at('2026-03-29T03:30','Europe/Madrid'),'Europe/Madrid'),'2026-03-29T03:30');
});
test('Mensaje de relevo contiene intervalo, zona y solicitud sin confirmar cobertura',()=>{
 const s=setup([]),t=task();const message=relayMessage({task:t,note:'Necesito compañía'},s);assert.match(message,/2026/);assert.match(message,/America\/La_Paz/);assert.match(message,/Necesito compañía/);assert.match(message,/no confirma/);assert.doesNotMatch(message,/https?:/);
});

test('Editar Leo martes 20/10: disponibilidad, nueva confirmación y exclusión de su propio horario',()=>{
 const s=seed();
 const original=task('2026-10-20T19:00','2026-10-20T20:00',{assignee:'leo',type:RELAY,status:'aceptada'});
 s.tasks=[original];
 const updated={...original,start:stamp('2026-10-20T19:30'),end:stamp('2026-10-20T20:30')};
 assert.ok(available(s.people.find(p=>p.id==='leo'),updated,s.zone));
 assert.equal(editTask(s,updated).status,'propuesta');
 assert.equal(original.status,'aceptada');
 assert.throws(()=>editTask(s,{...updated,end:stamp('2026-10-20T23:30')}),/no está disponible/);
});

test('Al guardar se rechaza cruce con otro compromiso aceptado; consecutivos y otra persona se permiten',()=>{
 const original=task('2026-10-26T09:00','2026-10-26T10:00',{status:'aceptada'});
 const neighbor=task('2026-10-26T10:30','2026-10-26T11:30',{status:'aceptada'});
 const s=setup([original,neighbor],[person('a'),person('b')]);
 const updated={...original,start:stamp('2026-10-26T09:30'),end:stamp('2026-10-26T10:45')};
 assert.throws(()=>editTask(s,updated),/se solapa/);
 assert.equal(editTask(s,{...updated,end:neighbor.start}).status,'propuesta');
 assert.equal(editTask(s,{...updated,assignee:'b'}).status,'propuesta');
 neighbor.status='cancelada';assert.equal(editTask(s,updated).status,'propuesta');
});
