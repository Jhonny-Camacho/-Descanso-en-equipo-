import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { randomBytes, randomUUID, createHash, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { mkdirSync, chmodSync, readFileSync, existsSync, statSync } from 'node:fs';
import { dirname, resolve, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { HttpError, requireThat, validateChange } from './rules.js';
const scrypt=promisify(scryptCallback), hash=s=>createHash('sha256').update(s).digest('hex');
const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const DAY=86400000;
export function createApp({dbPath=resolve(ROOT,'data/descanso.sqlite'), origin='http://localhost:3001',secure=origin.startsWith('https:'), now=Date.now}={}){
 if(dbPath!==':memory:'){mkdirSync(dirname(dbPath),{recursive:true,mode:0o700});}
 const db=new DatabaseSync(dbPath);
 if(dbPath!==':memory:')chmodSync(dbPath,0o600);
 db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT NOT NULL UNIQUE,name TEXT NOT NULL,password TEXT NOT NULL,salt TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),expires INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS families(id TEXT PRIMARY KEY,owner_id TEXT NOT NULL REFERENCES users(id),plan TEXT NOT NULL CHECK(json_valid(plan)),revision INTEGER NOT NULL DEFAULT 1);
 CREATE TABLE IF NOT EXISTS members(family_id TEXT NOT NULL REFERENCES families(id),user_id TEXT NOT NULL REFERENCES users(id),PRIMARY KEY(family_id,user_id));
 CREATE TABLE IF NOT EXISTS invites(id TEXT PRIMARY KEY,family_id TEXT NOT NULL REFERENCES families(id),token TEXT NOT NULL UNIQUE,expires INTEGER NOT NULL,revoked INTEGER NOT NULL DEFAULT 0,used_by TEXT REFERENCES users(id));
 CREATE TABLE IF NOT EXISTS attempts(key TEXT PRIMARY KEY,count INTEGER NOT NULL,expires INTEGER NOT NULL);`);
 const transaction=fn=>{db.exec('BEGIN IMMEDIATE');try{const result=fn();db.exec('COMMIT');return result;}catch(e){db.exec('ROLLBACK');throw e;}};
 const member=(fid,uid)=>db.prepare('SELECT f.* FROM families f JOIN members m ON m.family_id=f.id WHERE f.id=? AND m.user_id=?').get(fid,uid);
 const owned=(fid,uid)=>db.prepare('SELECT * FROM families WHERE id=? AND owner_id=?').get(fid,uid);
 const cookieName=secure?'__Host-descanso':'descanso_session';
 const sessionCookie=(token,age=604800)=>`${cookieName}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${age}${secure?'; Secure':''}`;
 function rateLimit(key,max){
  const t=now();db.prepare('DELETE FROM attempts WHERE expires<?').run(t);
  const row=db.prepare('SELECT * FROM attempts WHERE key=?').get(key);
  requireThat(!row||row.count<max,429,'Demasiados intentos. Espera 15 minutos.');
  db.prepare('INSERT INTO attempts VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1').run(key,t+900000);
 }
 async function body(req){
  requireThat(req.headers['content-type']?.split(';')[0]==='application/json',415,'Se necesita JSON.');
  let value='';for await(const chunk of req){value+=chunk;requireThat(Buffer.byteLength(value)<=2000000,413,'El plan es demasiado grande.');}
  try{return JSON.parse(value||'{}');}catch{throw new HttpError(400,'JSON no válido.');}
 }
 async function handler(req,res){
  const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"};
  const send=(status,data,extra={})=>{res.writeHead(status,{...headers,'Content-Type':'application/json; charset=utf-8',...extra});res.end(JSON.stringify(data));};
  try{
   const path=new URL(req.url,origin).pathname;
   if(!path.startsWith('/api/')){
    requireThat(req.method==='GET'||req.method==='HEAD',405,'Método no permitido.');
    const demo=path==='/'||path==='/index.html'||path.startsWith('/assets/')||path==='/descanso-demo.html';
    const base=resolve(ROOT,demo?'dist':'dist-real');
    const file=resolve(base,'.'+decodeURIComponent(path==='/'?'/index.html':path));
    requireThat(file.startsWith(base+'/')&&existsSync(file)&&statSync(file).isFile(),404,'Página no encontrada. Ejecuta npm run build.');
    const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'};
    const content=readFileSync(file);
    if(path==='/descanso-demo.html'){const script=content.toString('utf8').match(/<script type="module">([\s\S]*?)<\/script>/)?.[1];if(script)headers['Content-Security-Policy']=headers['Content-Security-Policy'].replace("script-src 'self'","script-src 'self' 'sha256-"+createHash('sha256').update(script).digest('base64')+"'");}
    res.writeHead(200,{...headers,'Content-Type':types[extname(file)]||'application/octet-stream'});res.end(req.method==='HEAD'?undefined:content);return;
   }
   if(!['GET','HEAD'].includes(req.method))requireThat(req.headers.origin===origin,403,'Origen de la solicitud no autorizado.');
   const rawCookie=req.headers.cookie?.split(';').map(s=>s.trim()).find(s=>s.startsWith(cookieName+'='))?.slice(cookieName.length+1);
   const user=rawCookie?db.prepare('SELECT u.id,u.email,u.name FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>?').get(hash(rawCookie),now()):null;
   if(path==='/api/register'||path==='/api/login'){
    requireThat(req.method==='POST',405,'Método no permitido.');
    rateLimit('auth-ip:'+req.socket.remoteAddress,60);
    const b=await body(req);const email=String(b.email||'').trim().toLowerCase();
    requireThat(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)&&email.length<=254,422,'Revisa el correo.');
    requireThat(typeof b.password==='string'&&b.password.length>=12&&b.password.length<=128,422,'Usa una contraseña de 12 a 128 caracteres.');
    rateLimit('auth-email:'+hash(email),20);
    let account;
    if(path==='/api/register'){
     requireThat(typeof b.name==='string'&&b.name.trim().length>0&&b.name.trim().length<=40,422,'Indica un alias de hasta 40 caracteres.');
     const salt=randomBytes(16).toString('hex');const password=Buffer.from(await scrypt(b.password,salt,64)).toString('hex');
     account={id:randomUUID(),email,name:b.name.trim()};
     try{db.prepare('INSERT INTO users VALUES(?,?,?,?,?)').run(account.id,email,account.name,password,salt);}catch(e){if(e.code?.includes('CONSTRAINT')||e.message.includes('UNIQUE'))throw new HttpError(409,'No se pudo crear la cuenta. Prueba iniciar sesión con ese correo.');throw e;}
    }else{
     const row=db.prepare('SELECT * FROM users WHERE email=?').get(email);
     const candidate=Buffer.from(await scrypt(b.password,row?.salt||'unused-account-salt',64));
     requireThat(row&&timingSafeEqual(candidate,Buffer.from(row.password,'hex')),401,'Correo o contraseña incorrectos.');
     account={id:row.id,email:row.email,name:row.name};
    }
    const token=randomBytes(32).toString('base64url');
    db.prepare('DELETE FROM sessions WHERE expires<?').run(now());
    db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(hash(token),account.id,now()+7*DAY);
    send(200,{user:account},{'Set-Cookie':sessionCookie(token)});return;
   }
   requireThat(user,401,'Inicia sesión para continuar.');
   if(path==='/api/session'&&req.method==='GET'){send(200,{user});return;}
   if(path==='/api/logout'&&req.method==='POST'){db.prepare('DELETE FROM sessions WHERE token=?').run(hash(rawCookie));send(200,{ok:true},{'Set-Cookie':sessionCookie('',0)});return;}
   if(path==='/api/families'&&req.method==='GET'){
    send(200,{families:db.prepare('SELECT f.id,json_extract(f.plan,\'$.family\') AS name FROM families f JOIN members m ON m.family_id=f.id WHERE m.user_id=?').all(user.id)});return;
   }
   if(path==='/api/families'&&req.method==='POST'){
    const b=await body(req);
    requireThat(typeof b.family==='string'&&b.family.trim().length>0&&b.family.length<=60,422,'Indica un nombre familiar de hasta 60 caracteres.');
    try{new Intl.DateTimeFormat('es',{timeZone:b.zone});requireThat(typeof b.zone==='string',422,'Indica una zona horaria.');}catch{throw new HttpError(422,'Usa una zona como America/La_Paz.');}
    const id=randomUUID();
    const plan={version:1,family:b.family.trim(),zone:b.zone,people:[{id:user.id,name:user.name,babyCare:true,availability:[]}],tasks:[],rests:[],actor:user.id,reviews:{},wizard:{step:1,draft:null},custom:true};
    transaction(()=>{db.prepare('INSERT INTO families(id,owner_id,plan) VALUES(?,?,?)').run(id,user.id,JSON.stringify(plan));db.prepare('INSERT INTO members VALUES(?,?)').run(id,user.id);});
    send(201,{id});return;
   }
   if(path==='/api/invitations/accept'&&req.method==='POST'){
    const b=await body(req);requireThat(typeof b.token==='string'&&b.token.length<=100,422,'Enlace no válido.');
    const id=transaction(()=>{
     const inv=db.prepare('SELECT * FROM invites WHERE token=? AND revoked=0 AND used_by IS NULL AND expires>?').get(hash(b.token),now());
     requireThat(inv,410,'La invitación caducó, fue revocada o ya se utilizó. Pide un nuevo enlace.');
     requireThat(!member(inv.family_id,user.id),409,'Ya perteneces a esta familia.');
     const row=db.prepare('SELECT * FROM families WHERE id=?').get(inv.family_id);const plan=JSON.parse(row.plan);
     requireThat(plan.people.length<100,422,'La familia ha alcanzado el límite de adultos.');
     plan.people.push({id:user.id,name:user.name,babyCare:false,availability:[]});
     db.prepare('INSERT INTO members VALUES(?,?)').run(inv.family_id,user.id);
     db.prepare('UPDATE families SET plan=?,revision=revision+1 WHERE id=?').run(JSON.stringify(plan),inv.family_id);
     db.prepare('UPDATE invites SET used_by=? WHERE id=?').run(user.id,inv.id);return inv.family_id;
    });send(200,{id});return;
   }
   const match=path.match(/^\/api\/families\/([a-zA-Z0-9-]+)(?:\/(invitations)(?:\/([a-zA-Z0-9-]+))?)?$/);
   requireThat(match,404,'Recurso no encontrado.');const [,fid,sub,iid]=match;
   if(sub){
    requireThat(owned(fid,user.id),404,'Recurso no encontrado.');
    if(req.method==='GET'&&!iid){send(200,{invitations:db.prepare('SELECT id,expires,revoked,used_by IS NOT NULL AS used FROM invites WHERE family_id=? ORDER BY expires DESC').all(fid)});return;}
    if(req.method==='POST'&&!iid){
     rateLimit('invite:'+fid,30);
     const token=randomBytes(32).toString('base64url'),id=randomUUID(),expires=now()+2*DAY;
     db.prepare('INSERT INTO invites(id,family_id,token,expires) VALUES(?,?,?,?)').run(id,fid,hash(token),expires);
     send(201,{id,expires,url:origin+'/familia.html#invitacion='+token});return;
    }
    if(req.method==='DELETE'&&iid){const result=db.prepare('UPDATE invites SET revoked=1 WHERE id=? AND family_id=?').run(iid,fid);requireThat(result.changes,404,'Recurso no encontrado.');send(200,{ok:true});return;}
    throw new HttpError(405,'Método no permitido.');
   }
   if(req.method==='GET'){
    const row=member(fid,user.id);requireThat(row,404,'Recurso no encontrado.');
    send(200,{id:fid,revision:row.revision,owner:row.owner_id===user.id,plan:{...JSON.parse(row.plan),actor:user.id}});return;
   }
   if(req.method==='PUT'){
    const b=await body(req);
    const result=transaction(()=>{
     const row=member(fid,user.id);requireThat(row,404,'Recurso no encontrado.');
     requireThat(Number.isSafeInteger(b.revision)&&b.revision===row.revision,409,'Otra persona cambió el plan. Tu cambio no se guardó. Conserva tu borrador y carga la versión actual antes de reintentarlo.');
     const after=structuredClone(b.plan);after.actor=user.id;after.wizard={step:1,draft:null};
     validateChange(JSON.parse(row.plan),after,user.id);
     const updated=db.prepare('UPDATE families SET plan=?,revision=revision+1 WHERE id=? AND revision=? AND EXISTS(SELECT 1 FROM members WHERE family_id=families.id AND user_id=?)').run(JSON.stringify(after),fid,b.revision,user.id);
     requireThat(updated.changes===1,409,'El plan cambió. Recarga la versión actual.');return {revision:row.revision+1,plan:after};
    });send(200,result);return;
   }
   throw new HttpError(405,'Método no permitido.');
  }catch(e){const databaseError=String(e.code||'').includes('SQLITE')||/database|disk I\/O/i.test(e.message);send(e.status||(databaseError?503:422),{error:databaseError?'No se pudo confirmar la escritura en la base de datos. Conserva tus cambios y vuelve a intentarlo.':e instanceof TypeError?'La solicitud no es válida. Revisa los datos del plan.':e.message});}
 }
 const server=createServer(handler);
 return {server,db,close:()=>new Promise(resolve=>server.close(()=>{db.close();resolve();}))};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const port=Number(process.env.PORT||3001),origin=process.env.APP_ORIGIN||`http://localhost:${port}`;
 requireThat(origin.startsWith('https://')||/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin),500,'Configura APP_ORIGIN con HTTPS para acceso externo.');
 const app=createApp({dbPath:process.env.DB_PATH||resolve(ROOT,'data/descanso.sqlite'),origin});
 app.server.listen(port,process.env.HOST||'127.0.0.1',()=>console.log(`Descanso en equipo: ${origin}/familia.html`));
}
