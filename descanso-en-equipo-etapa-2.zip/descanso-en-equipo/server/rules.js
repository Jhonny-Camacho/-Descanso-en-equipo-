import { validateState } from '../src/storage.js';
import { accept, editTask, available } from '../src/planner.js';
export class HttpError extends Error { constructor(status,message){super(message);this.status=status;} }
export const requireThat=(condition,status,message)=>{if(!condition)throw new HttpError(status,message);};
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
// The identity comes exclusively from the server session, never from plan.actor.
export function validateChange(before,after,userId){
 validateState(after);
 requireThat(after.zone===before.zone,422,'La zona horaria no se puede cambiar con un plan activo.');
 requireThat(equal(after.people.map(p=>p.id),before.people.map(p=>p.id)),403,'Los adultos se incorporan únicamente mediante invitación.');
 for(const p of after.people){
  const old=before.people.find(x=>x.id===p.id);
  requireThat(p.id===userId||equal(p,old),403,'Solo puedes editar tu propia disponibilidad y alias.');
 }
 const oldTasks=new Map(before.tasks.map(t=>[t.id,t]));
 for(const task of after.tasks){
  const old=oldTasks.get(task.id);
  if(equal(task,old))continue;
  if(!old){
   requireThat(task.status==='propuesta',403,'Una tarea nueva necesita aceptación de su responsable.');
   editTask({...after,tasks:before.tasks},task);
  }else{
   const changed=['type','description','start','end','assignee'].some(k=>task[k]!==old[k]);
   if(changed){
    requireThat(task.status==='propuesta',403,'Editar una tarea requiere una nueva confirmación.');
    editTask({...after,tasks:before.tasks},task);
   }else if(task.status!==old.status){
    if(task.status==='aceptada'){
     requireThat(old.assignee===userId,403,'Solo el responsable puede aceptar su tarea.');
     accept({...after,tasks:after.tasks.map(t=>t.id===task.id?old:t)},task.id,userId);
    }else if(task.status==='realizada'){
     requireThat(old.assignee===userId&&old.status==='aceptada',403,'Solo el responsable puede completar una tarea aceptada.');
    }else requireThat(task.status==='cancelada',403,'No se permite ese cambio de estado.');
   }
  }
  if(task.type==='Tarea personalizada')requireThat(task.description.trim(),422,'Describe la tarea personalizada.');
 }
 // Availability changes may flag an existing accepted task, but cannot be used
 // in the same request to bypass the checks for a new acceptance or proposal.
 for(const task of after.tasks.filter(t=>t.status==='aceptada')){
  const old=oldTasks.get(task.id);
  if(!old||old.status!=='aceptada')requireThat(available(after.people.find(p=>p.id===task.assignee),task,after.zone),422,'La tarea queda fuera de disponibilidad.');
 }
 return after;
}
