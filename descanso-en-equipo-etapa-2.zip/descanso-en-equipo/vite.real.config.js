import { defineConfig } from 'vite';
export default defineConfig({build:{outDir:'dist-real',assetsDir:'real-assets',rollupOptions:{input:'familia.html'}}});
